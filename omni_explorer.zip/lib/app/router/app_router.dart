/// @file app_router.dart
/// @brief Routeur principal de l'application avec go_router.
///
/// Définit toutes les routes de l'application et gère la navigation
/// entre les différentes fonctionnalités d'OmniExplorer.

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../features/home/screens/home_screen.dart';
import '../../features/file_explorer/screens/file_explorer_screen.dart';
import '../../features/media_player/screens/media_player_screen.dart';
import '../../features/image_viewer/screens/image_viewer_screen.dart';
import '../../features/text_editor/screens/text_editor_screen.dart';
import '../../features/markdown_viewer/screens/markdown_viewer_screen.dart';
import '../../features/pdf_viewer/screens/pdf_viewer_screen.dart';

/// @brief Noms des routes pour navigation typée.
class AppRoutes {
  static const String home = '/';
  static const String explorer = '/explorer';
  static const String mediaPlayer = '/media-player';
  static const String imageViewer = '/image-viewer';
  static const String textEditor = '/text-editor';
  static const String markdownViewer = '/markdown-viewer';
  static const String pdfViewer = '/pdf-viewer';
}

/// @brief Configuration du routeur go_router.
///
/// Utilise des paramètres extra pour passer des données complexes
/// entre les routes (chemins de fichiers, listes, etc.).
final GoRouter appRouter = GoRouter(
  initialLocation: AppRoutes.home,
  debugLogDiagnostics: false,
  routes: [
    // ─── Accueil ────────────────────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.home,
      name: 'home',
      pageBuilder: (context, state) => _fadePage(
        state,
        const HomeScreen(),
      ),
    ),

    // ─── Explorateur de fichiers ─────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.explorer,
      name: 'explorer',
      pageBuilder: (context, state) {
        return _slidePage(
          state,
          const FileExplorerScreen(),
        );
      },
    ),

    // ─── Lecteur multimédia ──────────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.mediaPlayer,
      name: 'mediaPlayer',
      pageBuilder: (context, state) {
        final args = state.extra as MediaPlayerArgs;
        return _slidePage(
          state,
          MediaPlayerScreen(
            filePath: args.filePath,
            playlist:    args.playlist,
          ),
        );
      },
    ),

    // ─── Visionneur d'images ─────────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.imageViewer,
      name: 'imageViewer',
      pageBuilder: (context, state) {
        final args = state.extra as ImageViewerArgs;
        return _slidePage(
          state,
          ImageViewerScreen(
            imagePath:  args.filePath,
            allImages:  args.imageFiles ?? [args.filePath],
          ),
        );
      },
    ),

    // ─── Éditeur de texte/code ───────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.textEditor,
      name: 'textEditor',
      pageBuilder: (context, state) {
        final filePath = state.extra as String?;
        return _slidePage(
          state,
          TextEditorScreen(initialFilePath: filePath),
        );
      },
    ),

    // ─── Visionneur Markdown ─────────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.markdownViewer,
      name: 'markdownViewer',
      pageBuilder: (context, state) {
        final filePath = state.extra as String;
        return _slidePage(
          state,
          MarkdownViewerScreen(filePath: filePath),
        );
      },
    ),

    // ─── Visionneur PDF ──────────────────────────────────────────────────────
    GoRoute(
      path: AppRoutes.pdfViewer,
      name: 'pdfViewer',
      pageBuilder: (context, state) {
        final filePath = state.extra as String;
        return _slidePage(
          state,
          PdfViewerScreen(filePath: filePath),
        );
      },
    ),
  ],

  // ─── Gestion d'erreur ────────────────────────────────────────────────────
  errorPageBuilder: (context, state) => MaterialPage(
    child: Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text(
              'Page introuvable',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              state.error.toString(),
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => context.go(AppRoutes.home),
              child: const Text('Retour à l\'accueil'),
            ),
          ],
        ),
      ),
    ),
  ),
);

// ─── Helpers de transition ────────────────────────────────────────────────────

/// @brief Transition en fondu (pour l'accueil).
CustomTransitionPage<void> _fadePage(GoRouterState state, Widget child) {
  return CustomTransitionPage<void>(
    key: state.pageKey,
    child: child,
    transitionDuration: const Duration(milliseconds: 200),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      return FadeTransition(opacity: animation, child: child);
    },
  );
}

/// @brief Transition en glissement (pour les écrans secondaires).
CustomTransitionPage<void> _slidePage(GoRouterState state, Widget child) {
  return CustomTransitionPage<void>(
    key: state.pageKey,
    child: child,
    transitionDuration: const Duration(milliseconds: 250),
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      final tween = Tween(
        begin: const Offset(1.0, 0.0),
        end: Offset.zero,
      ).chain(CurveTween(curve: Curves.easeInOutCubic));
      return SlideTransition(
        position: animation.drive(tween),
        child: child,
      );
    },
  );
}

// ─── Arguments typés ─────────────────────────────────────────────────────────

/// @brief Arguments pour le lecteur multimédia.
class MediaPlayerArgs {
  /// Chemin du fichier principal à ouvrir.
  final String filePath;

  /// Playlist optionnelle (liste de chemins).
  final List<String>? playlist;

  /// Index initial dans la playlist.
  final int initialIndex;

  const MediaPlayerArgs({
    required this.filePath,
    this.playlist,
    this.initialIndex = 0,
  });
}

/// @brief Arguments pour le visionneur d'images.
class ImageViewerArgs {
  /// Chemin du fichier image à ouvrir.
  final String filePath;

  /// Liste de toutes les images du dossier pour la navigation.
  final List<String>? imageFiles;

  /// Index initial dans la liste d'images.
  final int initialIndex;

  const ImageViewerArgs({
    required this.filePath,
    this.imageFiles,
    this.initialIndex = 0,
  });
}

// ─── Extension de navigation ──────────────────────────────────────────────────

/// @brief Extensions utilitaires sur BuildContext pour la navigation.
extension AppNavigation on BuildContext {
  /// Ouvre l'explorateur à un chemin donné.
  void goExplorer({String? path}) =>
      go(AppRoutes.explorer, extra: path);

  /// Ouvre le lecteur multimédia.
  void goMediaPlayer({
    required String filePath,
    List<String>? playlist,
    int initialIndex = 0,
  }) =>
      go(
        AppRoutes.mediaPlayer,
        extra: MediaPlayerArgs(
          filePath: filePath,
          playlist: playlist,
          initialIndex: initialIndex,
        ),
      );

  /// Ouvre le visionneur d'images.
  void goImageViewer({
    required String filePath,
    List<String>? imageFiles,
    int initialIndex = 0,
  }) =>
      go(
        AppRoutes.imageViewer,
        extra: ImageViewerArgs(
          filePath: filePath,
          imageFiles: imageFiles,
          initialIndex: initialIndex,
        ),
      );

  /// Ouvre l'éditeur de texte.
  void goTextEditor({String? filePath}) =>
      go(AppRoutes.textEditor, extra: filePath);

  /// Ouvre le visionneur Markdown.
  void goMarkdownViewer(String filePath) =>
      go(AppRoutes.markdownViewer, extra: filePath);

  /// Ouvre le visionneur PDF.
  void goPdfViewer(String filePath) =>
      go(AppRoutes.pdfViewer, extra: filePath);
}
