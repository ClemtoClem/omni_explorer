/// @file app_constants.dart
/// @brief Constantes globales de l'application OmniExplorer.

/// @class AppConstants
/// @brief Constantes globales de l'application.
class AppConstants {
  AppConstants._();

  static const String appName    = 'OmniExplorer';
  static const String appVersion = '1.0.0';

  // ── Préférences ───────────────────────────────────────────────────────────
  static const String prefThemeMode    = 'theme_mode';
  static const String prefViewMode     = 'view_mode';
  static const String prefSortBy       = 'sort_by';
  static const String prefSortAsc      = 'sort_asc';
  static const String prefShowHidden   = 'show_hidden';
  static const String prefShortcuts    = 'shortcuts';
  static const String prefBookmarks    = 'bookmarks';
  static const String prefRecentFiles  = 'recent_files';
  static const String prefPlaylistsKey = 'playlists';

  // ── Thème ─────────────────────────────────────────────────────────────────
  static const String prefThemePreset  = 'theme_preset';
  static const String prefCustomAccent = 'custom_accent_color';

  // ── Corbeille ─────────────────────────────────────────────────────────────
  static const String trashFolderName  = '.omni_trash';
  static const String trashMetaFile    = '.trash_meta.json';

  // ── Limites ───────────────────────────────────────────────────────────────
  static const int maxRecentFiles      = 20;
  static const int maxUndoHistory      = 50;
  static const int slideshowDefaultMs  = 3000;

  // ── Extensions par catégorie ──────────────────────────────────────────────

  static const Set<String> audioExtensions = {
    'mp3', 'flac', 'wav', 'ogg', 'aac', 'm4a', 'opus', 'wma', 'aiff',
  };

  static const Set<String> videoExtensions = {
    'mp4', 'mkv', 'avi', 'mov', 'wmv', 'flv', 'webm', 'm4v', '3gp', 'ts',
  };

  static const Set<String> imageExtensions = {
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg', 'ico',
    'tiff', 'tif', 'heic', 'heif', 'avif',
  };

  static const Set<String> pdfExtensions  = {'pdf'};

  static const Set<String> markdownExtensions = {'md', 'markdown'};

  static const Set<String> archiveExtensions = {
    'zip', 'tar', 'gz', 'bz2', 'xz', '7z', 'rar', 'tar.gz', 'tar.bz2',
  };

  /// Extensions reconnues par l'éditeur de code avec coloration syntaxique.
  static const Set<String> codeExtensions = {
    'dart', 'py', 'js', 'ts', 'jsx', 'tsx', 'html', 'htm', 'css', 'scss',
    'sass', 'json', 'yaml', 'yml', 'xml', 'java', 'kt', 'c', 'cpp', 'h', 'inl',
    'hpp', 'cs', 'go', 'rs', 'rb', 'php', 'swift', 'sh', 'bash', 'zsh',
    'fish', 'sql', 'lua', 'r', 'toml', 'ini', 'cfg', 'conf', 'dockerfile',
    'makefile', 'cmake',
  };

  static const Set<String> textExtensions = {
    'txt', 'log', 'csv', 'tsv', 'nfo', 'srt', 'vtt',
  };

  static const Set<String> binaryExtensions = {
    'bin', 'dat', 'raw', 'exe', 'dll', 'so', 'dylib', 'elf',
    'o', 'obj', 'a', 'lib',
    'db', 'sqlite', 'sqlite3',
    'iso', 'img', 'dex', 'class',
    'pak', 'rom', 'fw', 'hex',
  };
}

/// @enum FileCategory
/// @brief Catégories de fichiers reconnues par l'application.
enum FileCategory {
  folder,
  audio,
  video,
  image,
  pdf,
  markdown,
  code,
  text,
  archive,
  binary,
  unknown,
}

/// @enum SortMode
/// @brief Modes de tri pour l'explorateur de fichiers.
enum SortMode {
  name,
  date,
  size,
  type,
}

/// @enum ViewMode
/// @brief Modes d'affichage pour l'explorateur de fichiers.
enum ViewMode {
  list,
  grid,
}
