/// @file media_player_screen.dart
/// @brief Lecteur multimédia (audio + vidéo) avec playlist et visualiseur.
///
/// Fonctionnalités :
/// - Lecture audio avec visualiseur spectromètre animé
/// - Lecture vidéo avec Chewie (contrôles natifs)
/// - Gestion de playlists (création, modification, navigation)
/// - Modes de répétition et lecture aléatoire
/// - Contrôles : play/pause, suivant/précédent, seek, volume
///
/// @author OmniExplorer
/// @version 1.0

import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:path/path.dart' as p;
import '../../../app/constants/app_constants.dart';
import '../../../app/theme/app_theme.dart';
import '../../../core/utils/file_utils.dart';

/// Écran du lecteur multimédia.
class MediaPlayerScreen extends StatefulWidget {
  final String filePath;
  final List<String>? playlist;
  final int initialIndex;

  const MediaPlayerScreen({
    super.key,
    required this.filePath,
    this.playlist,
    this.initialIndex = 0,
  });

  @override
  State<MediaPlayerScreen> createState() => _MediaPlayerScreenState();
}

class _MediaPlayerScreenState extends State<MediaPlayerScreen>
    with TickerProviderStateMixin {

  // ── Audio ────────────────────────────────────────────────────────────────
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool get _isAudio => FileUtils.detectType(
      p.extension(widget.filePath).replaceFirst('.', '').toLowerCase()) ==
      FileCategory.audio;

  // ── Vidéo ────────────────────────────────────────────────────────────────
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  // ── Playlist ─────────────────────────────────────────────────────────────
  List<String> _playlist = [];
  int _currentIndex = 0;

  // ── État de lecture ───────────────────────────────────────────────────────
  bool _isPlaying = false;
  bool _isRepeat = false;
  bool _isShuffle = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;

  // ── UI ────────────────────────────────────────────────────────────────────
  bool _showPlaylist = false;

  // ── Animation visualiseur ─────────────────────────────────────────────────
  late AnimationController _visualizerController;
  static const int _barCount = 32;
  final _random = math.Random();
  List<double> _barHeights = List.filled(_barCount, 0.1);

  @override
  void initState() {
    super.initState();
    _initPlaylist();
    _initVisualizer();
    if (_isAudio) {
      _initAudio();
    } else {
      _initVideo();
    }
  }

  // ─── Initialisation playlist ──────────────────────────────────────────────

  void _initPlaylist() {
    _playlist = widget.playlist ?? [widget.filePath];
    _currentIndex = widget.initialIndex.clamp(0, _playlist.length - 1);
  }

  // ─── Initialisation audio ─────────────────────────────────────────────────

  Future<void> _initAudio() async {
    // Configurer la session audio
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());

    // Écouter les changements d'état
    _audioPlayer.playerStateStream.listen((state) {
      if (mounted) {
        setState(() {
          _isPlaying = state.playing;
        });
        if (state.playing) {
          _visualizerController.repeat();
          _updateVisualizerBars();
        } else {
          _visualizerController.stop();
        }
      }
    });

    _audioPlayer.positionStream.listen((pos) {
      if (mounted) setState(() => _position = pos);
    });

    _audioPlayer.durationStream.listen((dur) {
      if (mounted) setState(() => _duration = dur ?? Duration.zero);
    });

    _audioPlayer.processingStateStream.listen((state) {
      if (state == ProcessingState.completed) {
        _onTrackComplete();
      }
    });

    await _loadCurrentTrack();
  }

  Future<void> _loadCurrentTrack() async {
    if (_playlist.isEmpty) return;
    final path = _playlist[_currentIndex];
    try {
      await _audioPlayer.setFilePath(path);
      await _audioPlayer.play();
    } catch (e) {
      debugPrint('[MediaPlayer] Erreur chargement audio: $e');
    }
  }

  // ─── Initialisation vidéo ─────────────────────────────────────────────────

  Future<void> _initVideo() async {
    _videoController = VideoPlayerController.file(
      Uri.file(widget.filePath) as dynamic,
    );

    // Pour Flutter 3.x, utiliser VideoPlayerController.file directement
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse('file://${widget.filePath}'),
    );

    try {
      await _videoController!.initialize();
      _chewieController = ChewieController(
        videoPlayerController: _videoController!,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        showControlsOnInitialize: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: AppColors.accent,
          handleColor: AppColors.accent,
          bufferedColor: AppColors.accent.withAlpha(60),
          backgroundColor: AppColors.darkBorder,
        ),
      );
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('[MediaPlayer] Erreur vidéo: $e');
    }
  }

  // ─── Visualiseur ──────────────────────────────────────────────────────────

  void _initVisualizer() {
    _visualizerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _barHeights = List.generate(_barCount,
        (i) => 0.05 + math.sin(i * math.pi / _barCount) * 0.3);

    _visualizerController.addListener(() {
      if (_isPlaying && mounted) {
        setState(() {
          _updateVisualizerBars();
        });
      }
    });
  }

  void _updateVisualizerBars() {
    final now = DateTime.now().millisecondsSinceEpoch;
    for (int i = 0; i < _barCount; i++) {
      final freq = (i + 1) / _barCount;
      final timeOffset = now * 0.001 + i * 0.3;
      final baseWave = math.sin(timeOffset * 2.5 + i * 0.5) * 0.3;
      final midWave = math.sin(timeOffset * 4.0 + i * 0.8) * 0.2;
      final noise = (_random.nextDouble() - 0.5) * 0.1;

      // Simuler une courbe spectrale (plus fort dans les médiums)
      final spectralShape = math.exp(-math.pow((freq - 0.4) * 3, 2));

      _barHeights[i] = (0.05 +
              (baseWave + midWave + noise) * spectralShape +
              spectralShape * 0.4)
          .clamp(0.03, 1.0);
    }
  }

  // ─── Contrôles de lecture ─────────────────────────────────────────────────

  Future<void> _togglePlayPause() async {
    if (_isAudio) {
      if (_isPlaying) {
        await _audioPlayer.pause();
      } else {
        await _audioPlayer.play();
      }
    } else {
      if (_videoController?.value.isPlaying == true) {
        await _videoController?.pause();
      } else {
        await _videoController?.play();
      }
      setState(() => _isPlaying = _videoController?.value.isPlaying ?? false);
    }
  }

  Future<void> _skipNext() async {
    if (_playlist.isEmpty) return;
    int next;
    if (_isShuffle) {
      next = _random.nextInt(_playlist.length);
    } else {
      next = (_currentIndex + 1) % _playlist.length;
    }
    setState(() => _currentIndex = next);
    if (_isAudio) await _loadCurrentTrack();
  }

  Future<void> _skipPrevious() async {
    if (_isAudio && _position.inSeconds > 3) {
      await _audioPlayer.seek(Duration.zero);
      return;
    }
    int prev = _currentIndex <= 0 ? _playlist.length - 1 : _currentIndex - 1;
    setState(() => _currentIndex = prev);
    if (_isAudio) await _loadCurrentTrack();
  }

  Future<void> _seekTo(double value) async {
    final position = Duration(
        milliseconds: (value * _duration.inMilliseconds).toInt());
    if (_isAudio) {
      await _audioPlayer.seek(position);
    } else {
      await _videoController?.seekTo(position);
    }
  }

  void _onTrackComplete() {
    if (_isRepeat) {
      _audioPlayer.seek(Duration.zero);
      _audioPlayer.play();
    } else if (_currentIndex < _playlist.length - 1) {
      _skipNext();
    }
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  String _formatDuration(int totalSeconds) {
    final h = totalSeconds ~/ 3600;
    final m = (totalSeconds % 3600) ~/ 60;
    final s = totalSeconds % 60;
    if (h > 0) {
      return '${h.toString().padLeft(2, '0')}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
    }
    return '${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }

  // ─── Build ────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = isDark ? AppColors.darkSurface : AppColors.lightSurface;

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        title: Text(
          p.basename(_playlist.isNotEmpty
              ? _playlist[_currentIndex]
              : widget.filePath),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          if (_playlist.length > 1)
            IconButton(
              icon: const Icon(Icons.queue_music_rounded),
              onPressed: () => setState(() => _showPlaylist = !_showPlaylist),
              tooltip: 'Playlist',
            ),
        ],
      ),
      body: _isAudio
          ? _buildAudioPlayer(context, isDark)
          : _buildVideoPlayer(context),
    );
  }

  // ─── Lecteur Audio ────────────────────────────────────────────────────────

  Widget _buildAudioPlayer(BuildContext context, bool isDark) {
    final trackName = _playlist.isNotEmpty
        ? p.basenameWithoutExtension(_playlist[_currentIndex])
        : 'Audio';

    return Column(
      children: [
        Expanded(
          child: _showPlaylist
              ? _PlaylistPanel(
                  paths: _playlist,
                  currentIndex: _currentIndex,
                  onTap: (idx) async {
                    setState(() => _currentIndex = idx);
                    await _loadCurrentTrack();
                  },
                )
              : Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: AppSpacing.lg, vertical: AppSpacing.md),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Artwork placeholder
                      _AudioArtwork(
                          trackName: trackName, isDark: isDark),
                      const SizedBox(height: AppSpacing.xl),

                      // Titre
                      Text(
                        trackName,
                        style: Theme.of(context).textTheme.headlineSmall,
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        p.extension(_playlist.isNotEmpty
                                ? _playlist[_currentIndex]
                                : '')
                            .toUpperCase()
                            .replaceFirst('.', ''),
                        style: Theme.of(context).textTheme.bodySmall,
                      ),

                      const SizedBox(height: AppSpacing.xl),

                      // Visualiseur spectromètre
                      _AudioVisualizer(
                        barHeights: _barHeights,
                        isPlaying: _isPlaying,
                      ),
                    ],
                  ),
                ),
        ),

        // ── Contrôles ─────────────────────────────────────────────────────
        _buildAudioControls(context, isDark),
      ],
    );
  }

  Widget _buildAudioControls(BuildContext context, bool isDark) {
    final progress = _duration.inMilliseconds > 0
        ? _position.inMilliseconds / _duration.inMilliseconds
        : 0.0;

    return Container(
      padding: const EdgeInsets.fromLTRB(
          AppSpacing.md, 0, AppSpacing.md, AppSpacing.lg),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkSurface2 : AppColors.lightSurface2,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppRadius.lg),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: AppSpacing.sm),

          // Drag handle
          Container(
            width: 36,
            height: 4,
            decoration: BoxDecoration(
              color: isDark ? AppColors.darkBorder : AppColors.lightBorder,
              borderRadius: BorderRadius.circular(AppRadius.full),
            ),
          ),
          const SizedBox(height: AppSpacing.md),

          // Barre de progression
          SliderTheme(
            data: const SliderThemeData(
              trackHeight: 3,
              thumbShape: RoundSliderThumbShape(enabledThumbRadius: 6),
              overlayShape: RoundSliderOverlayShape(overlayRadius: 12),
            ),
            child: Slider(
              value: progress.clamp(0.0, 1.0),
              onChanged: _seekTo,
              activeColor: AppColors.accent,
              inactiveColor: isDark
                  ? AppColors.darkBorder
                  : AppColors.lightBorder,
            ),
          ),

          // Temps
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.md),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  _formatDuration(_position.inSeconds),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                Text(
                  _formatDuration(_duration.inSeconds),
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSpacing.sm),

          // Boutons principaux
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Aléatoire
              IconButton(
                icon: Icon(
                  Icons.shuffle_rounded,
                  color: _isShuffle
                      ? AppColors.accent
                      : (isDark
                          ? AppColors.darkSubtext
                          : AppColors.lightSubtext),
                ),
                onPressed: () => setState(() => _isShuffle = !_isShuffle),
              ),

              // Précédent
              IconButton(
                icon: const Icon(Icons.skip_previous_rounded, size: 32),
                onPressed: _skipPrevious,
              ),

              // Play/Pause
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: AppColors.accent,
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  icon: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: Icon(
                      _isPlaying
                          ? Icons.pause_rounded
                          : Icons.play_arrow_rounded,
                      key: ValueKey(_isPlaying),
                      color: Colors.white,
                      size: 28,
                    ),
                  ),
                  onPressed: _togglePlayPause,
                ),
              ),

              // Suivant
              IconButton(
                icon: const Icon(Icons.skip_next_rounded, size: 32),
                onPressed: _skipNext,
              ),

              // Répétition
              IconButton(
                icon: Icon(
                  _isRepeat
                      ? Icons.repeat_one_rounded
                      : Icons.repeat_rounded,
                  color: _isRepeat
                      ? AppColors.accent
                      : (isDark
                          ? AppColors.darkSubtext
                          : AppColors.lightSubtext),
                ),
                onPressed: () => setState(() => _isRepeat = !_isRepeat),
              ),
            ],
          ),
          const SizedBox(height: AppSpacing.sm),
        ],
      ),
    );
  }

  // ─── Lecteur Vidéo ────────────────────────────────────────────────────────

  Widget _buildVideoPlayer(BuildContext context) {
    if (_chewieController == null) {
      return Center(
        child: CircularProgressIndicator(color: AppColors.accent),
      );
    }
    return Chewie(controller: _chewieController!);
  }

  // ─── Dispose ──────────────────────────────────────────────────────────────

  @override
  void dispose() {
    _visualizerController.dispose();
    _audioPlayer.dispose();
    _chewieController?.dispose();
    _videoController?.dispose();
    super.dispose();
  }
}

// ─── Widget Artwork ───────────────────────────────────────────────────────────

class _AudioArtwork extends StatelessWidget {
  final String trackName;
  final bool isDark;
  const _AudioArtwork({required this.trackName, required this.isDark});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 200,
      height: 200,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isDark
              ? [AppColors.darkSurface2, AppColors.accentVariant]
              : [AppColors.accent.withAlpha(30), AppColors.accent.withAlpha(80)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(AppRadius.xl),
        boxShadow: [
          BoxShadow(
            color: AppColors.accent.withAlpha(50),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Icon(
        Icons.music_note_rounded,
        size: 80,
        color: AppColors.accent,
      ),
    );
  }
}

// ─── Widget Visualiseur ───────────────────────────────────────────────────────

/// Visualiseur spectromètre animé pour la lecture audio.
class _AudioVisualizer extends StatelessWidget {
  final List<double> barHeights;
  final bool isPlaying;

  const _AudioVisualizer({
    required this.barHeights,
    required this.isPlaying,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 80,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: List.generate(barHeights.length, (i) {
          final height = (barHeights[i] * 80).clamp(3.0, 80.0);
          final hue = (220 + i * 2.0) % 360;
          final color = HSLColor.fromAHSL(1.0, hue, 0.8, 0.6).toColor();

          return AnimatedContainer(
            duration: const Duration(milliseconds: 100),
            width: 6,
            height: isPlaying ? height : 3.0,
            margin: const EdgeInsets.symmetric(horizontal: 1),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [
                  AppColors.accent,
                  color,
                ],
              ),
              borderRadius: BorderRadius.circular(2),
            ),
          );
        }),
      ),
    );
  }
}

// ─── Widget Playlist ──────────────────────────────────────────────────────────

class _PlaylistPanel extends StatelessWidget {
  final List<String> paths;
  final int currentIndex;
  final void Function(int) onTap;

  const _PlaylistPanel({
    required this.paths,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(AppSpacing.sm),
      itemCount: paths.length,
      itemBuilder: (ctx, idx) {
        final isActive = idx == currentIndex;
        final name = p.basenameWithoutExtension(paths[idx]);
        return ListTile(
          selected: isActive,
          selectedColor: AppColors.accent,
          leading: isActive
              ? Icon(Icons.volume_up_rounded,
                  color: AppColors.accent, size: 20)
              : Text(
                  '${idx + 1}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
          title: Text(
            name,
            style: TextStyle(
              fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          onTap: () => onTap(idx),
        );
      },
    );
  }
}
