
/// @file home_screen.dart
/// @brief Shell principal de l'application avec navigation par onglets.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../app/constants/app_constants.dart';
import '../../../core/services/settings_service.dart';
import '../../../core/services/trash_service.dart';
import '../../../app/theme/app_theme.dart';
import '../../../core/utils/file_utils.dart';
import '../../file_explorer/screens/file_explorer_screen.dart';
import '../../code_editor/screens/code_editor_screen.dart';
import '../../media_player/screens/media_player_screen.dart';
import '../../image_viewer/screens/image_viewer_screen.dart';
import '../../pdf_viewer/screens/pdf_viewer_screen.dart';
import '../../markdown_viewer/screens/markdown_viewer_screen.dart';
import '../../settings/screens/theme_picker_screen.dart';

/// @class HomeScreen
/// @brief Widget racine de la navigation (NavigationBar en bas).
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    // Masque la barre de navigation Android pour maximiser l'espace.
    SystemChrome.setEnabledSystemUIMode(
        SystemUiMode.manual, overlays: [SystemUiOverlay.top]);

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: const [
          FileExplorerScreen(),
          _RecentFilesTab(),
          _SettingsTab(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.folder_outlined),
            selectedIcon: Icon(Icons.folder_rounded),
            label: 'Explorateur',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_outlined),
            selectedIcon: Icon(Icons.history_rounded),
            label: 'Recents',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded),
            label: 'Parametres',
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

/// @class _RecentFilesTab
/// @brief Onglet des fichiers recemment ouverts.
class _RecentFilesTab extends StatelessWidget {
  const _RecentFilesTab();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();
    final theme    = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Fichiers recents'),
        actions: [
          if (settings.recentFiles.isNotEmpty)
            TextButton(
              onPressed: settings.clearRecentFiles,
              child: const Text('Effacer'),
            ),
        ],
      ),
      body: settings.recentFiles.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.history_rounded,
                      size: 64,
                      color: theme.iconTheme.color?.withValues(alpha:0.2)),
                  const SizedBox(height: 12),
                  Text('Aucun fichier recent',
                      style: theme.textTheme.bodyMedium
                          ?.copyWith(color: theme.textTheme.bodySmall?.color)),
                ],
              ),
            )
          : ListView.builder(
              itemCount: settings.recentFiles.length,
              itemBuilder: (ctx, i) {
                final path = settings.recentFiles[i];
                final name = path.split('/').last;
                final cat  = FileUtils.categoryOfPath(path);
                return ListTile(
                  leading: Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: FileUtils.colorOf(cat).withValues(alpha:0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      FileUtils.iconOf(cat, path: path),
                      color: FileUtils.colorOf(cat),
                      size: 20,
                    ),
                  ),
                  title: Text(name,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(path,
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodySmall),
                  onTap: () => _openFile(ctx, path, cat),
                );
              },
            ),
    );
  }

  void _openFile(BuildContext ctx, String path, FileCategory cat) {
    ctx.read<SettingsService>();
    switch (cat) {
      case FileCategory.audio:
      case FileCategory.video:
        Navigator.push(ctx, MaterialPageRoute(
          builder: (_) => MediaPlayerScreen(filePath: path, playlist: [path])));
        break;
      case FileCategory.image:
        Navigator.push(ctx, MaterialPageRoute(
          builder: (_) => ImageViewerScreen(imagePath: path, allImages: [path])));
        break;
      case FileCategory.pdf:
        Navigator.push(ctx, MaterialPageRoute(
          builder: (_) => PdfViewerScreen(filePath: path)));
        break;
      case FileCategory.markdown:
        Navigator.push(ctx, MaterialPageRoute(
          builder: (_) => MarkdownViewerScreen(filePath: path)));
        break;
      default:
        Navigator.push(ctx, MaterialPageRoute(
          builder: (_) => CodeEditorScreen(path: path)));
        break;
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────

/// @class _SettingsTab
/// @brief Onglet des parametres.
class _SettingsTab extends StatelessWidget {
  const _SettingsTab();

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();
    final trash    = context.watch<TrashService>();
    final theme    = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Parametres')),
      body: ListView(
        children: [
          _SectionHeader('APPARENCE'),
          ListTile(
            leading: const Icon(Icons.palette_outlined),
            title: const Text('Theme'),
            subtitle: Text(
              '${settings.themePreset.emoji} ${settings.themePreset.name}  ·  ${_themeLabel(settings.themeMode)}',
            ),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => _pickTheme(context, settings),
          ),
          const Divider(height: 1),
          _SectionHeader('EXPLORATEUR'),
          SwitchListTile(
            secondary: const Icon(Icons.visibility_outlined),
            title: const Text('Fichiers caches'),
            subtitle: const Text('Afficher les fichiers et dossiers caches'),
            value: settings.showHidden,
            onChanged: settings.setShowHidden,
          ),
          ListTile(
            leading: const Icon(Icons.sort_rounded),
            title: const Text('Tri par defaut'),
            subtitle: Text(_sortLabel(settings.sortMode)),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => _pickSort(context, settings),
          ),
          const Divider(height: 1),
          _SectionHeader('CORBEILLE'),
          ListTile(
            leading: const Icon(Icons.delete_outline_rounded),
            title: const Text('Elements en corbeille'),
            trailing: Chip(
              label: Text('${trash.items.length}'),
              padding: EdgeInsets.zero,
              visualDensity: VisualDensity.compact,
            ),
          ),
          if (trash.items.isNotEmpty)
            ListTile(
              leading: Icon(Icons.delete_forever_rounded, color: AppColors.error),
              title: Text('Vider la corbeille',
                  style: TextStyle(color: AppColors.error)),
              subtitle: Text(
                  _formatSize(trash.totalSize),
                  style: theme.textTheme.bodySmall),
              onTap: () => _confirmEmptyTrash(context, trash),
            ),
          const Divider(height: 1),
          _SectionHeader('A PROPOS'),
          ListTile(
            leading: const Icon(Icons.info_outline_rounded),
            title: const Text('OmniExplorer'),
            subtitle: const Text('Version 1.0.0 — Flutter'),
          ),
        ],
      ),
    );
  }

  String _themeLabel(ThemeMode m) =>
      {ThemeMode.system: 'Systeme', ThemeMode.light: 'Clair', ThemeMode.dark: 'Sombre'}[m]!;

  String _sortLabel(SortMode m) =>
      {SortMode.name: 'Nom', SortMode.date: 'Date', SortMode.size: 'Taille', SortMode.type: 'Type'}[m]!;

  String _formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1048576) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / 1048576).toStringAsFixed(1)} MB';
  }

  void _pickTheme(BuildContext ctx, SettingsService s) {
    Navigator.push(
      ctx,
      MaterialPageRoute(builder: (_) => const ThemePickerScreen()),
    );
  }

  void _pickSort(BuildContext ctx, SettingsService s) {
    showDialog(
      context: ctx,
      builder: (_) => SimpleDialog(
        title: const Text('Trier par'),
        children: [
          for (final m in SortMode.values)
            SimpleDialogOption(
              onPressed: () { s.setSortMode(m); Navigator.pop(ctx); },
              child: Text({SortMode.name:'Nom', SortMode.date:'Date', SortMode.size:'Taille', SortMode.type:'Type'}[m]!),
            ),
        ],
      ),
    );
  }

  void _confirmEmptyTrash(BuildContext ctx, TrashService trash) async {
    final ok = await showDialog<bool>(
      context: ctx,
      builder: (_) => AlertDialog(
        title: const Text('Vider la corbeille'),
        content: const Text('Supprimer definitivement tous les elements ? Cette action est irreversible.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text('Vider', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );
    if (ok == true) await trash.emptyTrash();
  }
}

class _SectionHeader extends StatelessWidget {
  final String text;
  const _SectionHeader(this.text);
  @override
  Widget build(BuildContext ctx) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
    child: Text(text,
        style: Theme.of(ctx).textTheme.labelSmall?.copyWith(letterSpacing: 1.5)),
  );
}