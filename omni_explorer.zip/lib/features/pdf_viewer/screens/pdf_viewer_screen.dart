/// @file pdf_viewer_screen.dart
/// @brief Visionneur de fichiers PDF avec navigation par pages, zoom et partage.
///
/// Fonctionnalités :
/// - Rendu PDF natif via pdfx
/// - Navigation page précédente / suivante
/// - Saisie directe du numéro de page
/// - Zoom pinch-to-zoom
/// - Barre d'outils escamotable
/// - Partage du fichier

import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';

/// @class PdfViewerScreen
/// @brief Écran de visualisation d'un fichier PDF.
class PdfViewerScreen extends StatefulWidget {
  /// Chemin absolu du fichier PDF.
  final String filePath;

  const PdfViewerScreen({super.key, required this.filePath});

  @override
  State<PdfViewerScreen> createState() => _PdfViewerScreenState();
}

class _PdfViewerScreenState extends State<PdfViewerScreen> {
  /// Contrôleur du viewer PDF.
  late PdfControllerPinch _pdfController;

  /// Nombre total de pages.
  int _totalPages = 0;

  /// Page courante.
  int _currentPage = 1;

  /// Barre d'outils visible.
  bool _barsVisible = true;

  /// Erreur éventuelle.
  String? _error;

  @override
  void initState() {
    super.initState();
    _initController();
  }

  /// Initialise le contrôleur PDF.
  void _initController() {
    try {
      _pdfController = PdfControllerPinch(
        document: PdfDocument.openFile(widget.filePath),
      );
    } catch (e) {
      setState(() {
        _error = 'Impossible d\'ouvrir le PDF :\n$e';
              });
    }
  }

  @override
  void dispose() {
    _pdfController.dispose();
    super.dispose();
  }

  /// Partage le fichier PDF.
  void _share() {
    Share.shareXFiles([XFile(widget.filePath)]);
  }

  /// Affiche une boîte de dialogue pour aller à une page précise.
  void _goToPageDialog(BuildContext context) {
    final controller = TextEditingController(text: _currentPage.toString());
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Aller à la page'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          autofocus: true,
          decoration: InputDecoration(
            hintText: '1 – $_totalPages',
          ),
          onSubmitted: (v) {
            final page = int.tryParse(v);
            if (page != null && page >= 1 && page <= _totalPages) {
              _pdfController.jumpToPage(page);
            }
            Navigator.pop(ctx);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () {
              final page = int.tryParse(controller.text);
              if (page != null && page >= 1 && page <= _totalPages) {
                _pdfController.jumpToPage(page);
              }
              Navigator.pop(ctx);
            },
            child: const Text('Aller'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Viewer PDF
          if (_error == null)
            GestureDetector(
              onTap: () => setState(() => _barsVisible = !_barsVisible),
              child: PdfViewPinch(
                controller: _pdfController,
                onDocumentLoaded: (doc) {
                  setState(() {
                    _totalPages = doc.pagesCount;
                                      });
                },
                onPageChanged: (page) {
                  setState(() => _currentPage = page);
                },
                onDocumentError: (e) {
                  setState(() {
                    _error = 'Erreur chargement PDF : $e';
                                      });
                },
                builders: PdfViewPinchBuilders<DefaultBuilderOptions>(
                  options: const DefaultBuilderOptions(),
                  documentLoaderBuilder: (_) => const Center(
                    child: CircularProgressIndicator(),
                  ),
                  pageLoaderBuilder: (_) => const Center(
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  errorBuilder: (_, e) => Center(
                    child: Text(
                      'Erreur page : $e',
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                ),
              ),
            )
          else
            _ErrorView(message: _error!),

          // Barre supérieure
          AnimatedPositioned(
            duration: const Duration(milliseconds: 200),
            top: _barsVisible ? 0 : -80,
            left: 0,
            right: 0,
            child: _TopBar(
              fileName: p.basename(widget.filePath),
              onBack: () => Navigator.of(context).pop(),
              onShare: _share,
            ),
          ),

          // Barre inférieure
          AnimatedPositioned(
            duration: const Duration(milliseconds: 200),
            bottom: _barsVisible ? 0 : -80,
            left: 0,
            right: 0,
            child: _BottomBar(
              currentPage: _currentPage,
              totalPages: _totalPages,
              controller: _pdfController,
              onGoToPage: () => _goToPageDialog(context),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Widgets internes
// ---------------------------------------------------------------------------

/// @class _TopBar
/// @brief Barre de titre supérieure du viewer PDF.
class _TopBar extends StatelessWidget {
  final String fileName;
  final VoidCallback onBack;
  final VoidCallback onShare;

  const _TopBar({
    required this.fileName,
    required this.onBack,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top,
      ),
      color: Colors.black.withValues(alpha: 0.75),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: onBack,
            tooltip: 'Retour',
          ),
          Expanded(
            child: Text(
              fileName,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined, color: Colors.white),
            onPressed: onShare,
            tooltip: 'Partager',
          ),
        ],
      ),
    );
  }
}

/// @class _BottomBar
/// @brief Barre de navigation bas du viewer PDF.
class _BottomBar extends StatelessWidget {
  final int currentPage;
  final int totalPages;
  final PdfControllerPinch controller;
  final VoidCallback onGoToPage;

  const _BottomBar({
    required this.currentPage,
    required this.totalPages,
    required this.controller,
    required this.onGoToPage,
  });

  @override
  Widget build(BuildContext context) {
    final canPrev = currentPage > 1;
    final canNext = currentPage < totalPages;

    return Container(
      color: Colors.black.withValues(alpha: 0.75),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).padding.bottom + 8,
        top: 8,
        left: 16,
        right: 16,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Précédent
          IconButton(
            icon: const Icon(Icons.chevron_left, color: Colors.white),
            onPressed: canPrev
                ? () => controller.previousPage(
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeInOut,
                    )
                : null,
            tooltip: 'Page précédente',
          ),

          // Indicateur de page (cliquable)
          GestureDetector(
            onTap: totalPages > 0 ? onGoToPage : null,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                totalPages > 0
                    ? '$currentPage / $totalPages'
                    : '…',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),

          // Suivant
          IconButton(
            icon: const Icon(Icons.chevron_right, color: Colors.white),
            onPressed: canNext
                ? () => controller.nextPage(
                      duration: const Duration(milliseconds: 200),
                      curve: Curves.easeInOut,
                    )
                : null,
            tooltip: 'Page suivante',
          ),
        ],
      ),
    );
  }
}

/// @class _ErrorView
/// @brief Vue d'erreur du viewer PDF.
class _ErrorView extends StatelessWidget {
  final String message;
  const _ErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.picture_as_pdf,
                size: 64, color: Colors.redAccent),
            const SizedBox(height: 16),
            Text(
              message,
              style:
                  const TextStyle(color: Colors.white70, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.arrow_back),
              label: const Text('Retour'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white70,
                side: const BorderSide(color: Colors.white30),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
