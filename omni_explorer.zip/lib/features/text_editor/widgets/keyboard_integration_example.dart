/// @file keyboard_integration_example.dart
/// @brief Exemple d'intégration du clavier AZERTY dans TextEditorScreen.
///
/// Copiez-collez les sections marquées dans text_editor_screen.dart.

// ── 1. Import ──────────────────────────────────────────────────────────────
// Ajouter en haut de text_editor_screen.dart :
//
// import 'widgets/azerty_keyboard.dart';

// ── 2. State — ajout des champs ─────────────────────────────────────────────
/*
  bool _showCustomKeyboard = true;   // true = clavier virtuel affiché
  late final TextEditingController _codeController; // déjà existant

  // Passer showSoftKeyboard=false au TextField quand le clavier custom est actif
*/

// ── 3. Dans le build() — remplacer la partie TextField ─────────────────────
/*
  body: Column(
    children: [
      // ... barre d'onglets, breadcrumb, etc.

      Expanded(
        child: TextField(
          controller: _codeController,
          // Désactive le clavier système quand le clavier custom est actif
          readOnly: false,
          showCursor: true,
          keyboardType: _showCustomKeyboard
              ? TextInputType.none   // <-- empêche le clavier système
              : TextInputType.multiline,
          maxLines: null,
          // ... reste des paramètres
        ),
      ),

      // ── Clavier custom en bas d'écran ──
      if (_showCustomKeyboard)
        AzertyKeyboard(
          textController: _codeController,
          onKeyTap: (String char) {
            KeyboardController.handleKeyTap(_codeController, char);
          },
          onSpecialAction: (KeyboardAction action) {
            switch (action) {
              case KeyboardAction.ctrlS:
                _saveCurrentFile();
              case KeyboardAction.ctrlZ:
                _undo();
              case KeyboardAction.ctrlY:
                _redo();
              case KeyboardAction.ctrlF:
                setState(() => _searchBarVisible = true);
              case KeyboardAction.escape:
                setState(() => _searchBarVisible = false);
              default:
                // Délégué au KeyboardController
                KeyboardController.handleSpecialAction(_codeController, action);
            }
          },
        ),
    ],
  ),
*/

// ── 4. Bouton bascule clavier (dans AppBar actions) ────────────────────────
/*
  IconButton(
    icon: Icon(
      _showCustomKeyboard
          ? Icons.keyboard_hide
          : Icons.keyboard,
      color: _showCustomKeyboard
          ? Theme.of(context).colorScheme.primary
          : null,
    ),
    tooltip: _showCustomKeyboard
        ? 'Masquer le clavier custom'
        : 'Afficher le clavier AZERTY',
    onPressed: () => setState(() => _showCustomKeyboard = !_showCustomKeyboard),
  ),
*/

// ── 5. Résumé des KeyboardAction à gérer dans l'éditeur ────────────────────
//
// Action           │ Géré par                    │ Description
// ─────────────────┼─────────────────────────────┼───────────────────────────
// ctrlS            │ _saveCurrentFile()           │ Sauvegarde
// ctrlZ / ctrlY    │ _undo() / _redo()            │ Historique modifications
// ctrlF            │ Ouvre barre de recherche     │ Rechercher
// ctrlA            │ KeyboardController           │ Tout sélectionner
// ctrlC/X/V        │ KeyboardController           │ Presse-papiers
// backspace        │ KeyboardController           │ Suppression
// enter / tab      │ KeyboardController           │ Saut ligne / indentation
// arrowUp/Down     │ KeyboardController           │ Navigation ligne
// arrowLeft/Right  │ KeyboardController           │ Navigation curseur
// pageUp/pageDown  │ KeyboardController           │ Début/fin du document
// escape           │ Ferme recherche / dialogs    │
