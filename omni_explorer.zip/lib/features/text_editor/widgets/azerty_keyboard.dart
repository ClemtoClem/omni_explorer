/// @file azerty_keyboard.dart
/// @brief Clavier virtuel AZERTY personnalisé pour l'éditeur de code/texte.
///
/// Fonctionnalités :
/// - Disposition AZERTY complète (minuscules / majuscules / AltGr)
/// - Touches spéciales : Ctrl, Alt, AltGr, Tab, ↑ ↓ ← →, PgUp, PgDn
/// - Barre d'outils en en-tête avec les caractères de programmation les plus utilisés
/// - Modificateurs actifs affichés visuellement (toggle)
/// - Insertions via un callback [onKeyTap] et actions spéciales via [onSpecialAction]
/// - Architecture modulaire : chaque rangée est un widget isolé
///
/// Usage :
/// ```dart
/// AzertyKeyboard(
///   onKeyTap: (String char) { /* insérer dans le champ texte */ },
///   onSpecialAction: (KeyboardAction action) { /* gérer Tab, Back, Enter, etc. */ },
/// )
/// ```

import 'package:flutter/material.dart';

// ---------------------------------------------------------------------------
// Énumérations & modèles
// ---------------------------------------------------------------------------

/// @enum KeyboardAction
/// @brief Actions spéciales déclenchées par les touches non-imprimables.
enum KeyboardAction {
  backspace,
  enter,
  tab,
  escape,
  arrowUp,
  arrowDown,
  arrowLeft,
  arrowRight,
  pageUp,
  pageDown,
  home,
  end,
  ctrlC,
  ctrlV,
  ctrlX,
  ctrlZ,
  ctrlY,
  ctrlA,
  ctrlS,
  ctrlF,
}

/// @class _KeyDef
/// @brief Définition d'une touche simple ou à modificateur.
class _KeyDef {
  /// Label affiché par défaut.
  final String base;

  /// Label avec Shift actif (null = base en majuscule si lettre).
  final String? shift;

  /// Label avec AltGr actif.
  final String? altGr;

  /// Largeur relative de la touche (1.0 = touche standard).
  final double widthFactor;

  /// Si vrai, la touche est une touche de fonction (style différent).
  final bool isFn;

  const _KeyDef(
    this.base, {
    this.shift,
    this.altGr,
    this.widthFactor = 1.0,
    this.isFn = false,
  });
}

// ---------------------------------------------------------------------------
// Disposition AZERTY
// ---------------------------------------------------------------------------

/// Rangée 0 — Chiffres & symboles
const List<_KeyDef> _row0 = [
  _KeyDef('²', shift: '', altGr: ''),
  _KeyDef('1', shift: '!', altGr: ''),
  _KeyDef('2', shift: '"', altGr: '~'),
  _KeyDef('3', shift: "'", altGr: '#'),
  _KeyDef('4', shift: '(', altGr: '{'),
  _KeyDef('5', shift: '-', altGr: '['),
  _KeyDef('6', shift: '=', altGr: '|'),
  _KeyDef('7', shift: '_', altGr: '`'),
  _KeyDef('8', shift: '\\', altGr: '\\'),
  _KeyDef('9', shift: '^', altGr: '^'),
  _KeyDef('0', shift: 'à', altGr: '@'),
  _KeyDef(')', shift: '°', altGr: ']'),
  _KeyDef('=', shift: '+', altGr: '}'),
  _KeyDef('⌫', widthFactor: 1.5, isFn: true),
];

/// Rangée 1 — AZERTY
const List<_KeyDef> _row1 = [
  _KeyDef('⇥', widthFactor: 1.5, isFn: true),
  _KeyDef('a', shift: 'A', altGr: '@'),
  _KeyDef('z', shift: 'Z'),
  _KeyDef('e', shift: 'E', altGr: '€'),
  _KeyDef('r', shift: 'R'),
  _KeyDef('t', shift: 'T'),
  _KeyDef('y', shift: 'Y'),
  _KeyDef('u', shift: 'U'),
  _KeyDef('i', shift: 'I'),
  _KeyDef('o', shift: 'O'),
  _KeyDef('p', shift: 'P'),
  _KeyDef('^', shift: '¨', altGr: ''),
  _KeyDef('\$', shift: '£', altGr: '¤'),
  _KeyDef('↵', widthFactor: 1.5, isFn: true),
];

/// Rangée 2 — QSDFGH
const List<_KeyDef> _row2 = [
  _KeyDef('⇪', widthFactor: 1.7, isFn: true),
  _KeyDef('q', shift: 'Q'),
  _KeyDef('s', shift: 'S'),
  _KeyDef('d', shift: 'D'),
  _KeyDef('f', shift: 'F'),
  _KeyDef('g', shift: 'G'),
  _KeyDef('h', shift: 'H'),
  _KeyDef('j', shift: 'J'),
  _KeyDef('k', shift: 'K'),
  _KeyDef('l', shift: 'L'),
  _KeyDef('m', shift: 'M'),
  _KeyDef('ù', shift: '%'),
  _KeyDef('*', shift: 'μ', altGr: ''),
];

/// Rangée 3 — WXCV
const List<_KeyDef> _row3 = [
  _KeyDef('⇧', widthFactor: 2.2, isFn: true),
  _KeyDef('<', shift: '>'),
  _KeyDef('w', shift: 'W'),
  _KeyDef('x', shift: 'X'),
  _KeyDef('c', shift: 'C', altGr: '©'),
  _KeyDef('v', shift: 'V'),
  _KeyDef('b', shift: 'B'),
  _KeyDef('n', shift: 'N'),
  _KeyDef(',', shift: '?'),
  _KeyDef(';', shift: '.'),
  _KeyDef(':', shift: '/'),
  _KeyDef('!', shift: '§'),
  _KeyDef('⇧', widthFactor: 2.2, isFn: true),
];

/// Rangée 4 — Barre d'espace + modificateurs
const List<_KeyDef> _row4 = [
  _KeyDef('Ctrl', widthFactor: 1.4, isFn: true),
  _KeyDef('⊞', widthFactor: 1.0, isFn: true),
  _KeyDef('Alt', widthFactor: 1.2, isFn: true),
  _KeyDef(' ', widthFactor: 5.0),
  _KeyDef('AltGr', widthFactor: 1.3, isFn: true),
  _KeyDef('←', widthFactor: 1.0, isFn: true),
  _KeyDef('↑↓', widthFactor: 1.0, isFn: true),
  _KeyDef('→', widthFactor: 1.0, isFn: true),
];

// ---------------------------------------------------------------------------
// Caractères de programmation (barre d'outils)
// ---------------------------------------------------------------------------

/// @class _ProgChar
/// @brief Caractère de programmation affiché dans la barre d'outils.
class _ProgChar {
  final String char;
  final String? tooltip;
  const _ProgChar(this.char, {this.tooltip});
}

/// Groupes de caractères classés par catégorie.
const List<List<_ProgChar>> _progGroups = [
  // Accolades / parenthèses
  [
    _ProgChar('{', tooltip: 'Accolade ouvrante'),
    _ProgChar('}', tooltip: 'Accolade fermante'),
    _ProgChar('(', tooltip: 'Parenthèse ouvrante'),
    _ProgChar(')', tooltip: 'Parenthèse fermante'),
    _ProgChar('[', tooltip: 'Crochet ouvrant'),
    _ProgChar(']', tooltip: 'Crochet fermant'),
    _ProgChar('<', tooltip: 'Inférieur / Tag ouvrant'),
    _ProgChar('>', tooltip: 'Supérieur / Tag fermant'),
  ],
  // Opérateurs
  [
    _ProgChar('=', tooltip: 'Égal'),
    _ProgChar('==', tooltip: 'Égalité'),
    _ProgChar('!=', tooltip: 'Inégalité'),
    _ProgChar('===', tooltip: 'Strict égal'),
    _ProgChar('=>', tooltip: 'Flèche fat (lambda)'),
    _ProgChar('->', tooltip: 'Flèche mince'),
    _ProgChar('++', tooltip: 'Incrément'),
    _ProgChar('--', tooltip: 'Décrément'),
  ],
  // Ponctuation & structure
  [
    _ProgChar(';', tooltip: 'Point-virgule'),
    _ProgChar(':', tooltip: 'Deux-points'),
    _ProgChar(',', tooltip: 'Virgule'),
    _ProgChar('.', tooltip: 'Point'),
    _ProgChar('...', tooltip: 'Spread / Rest'),
    _ProgChar('?', tooltip: 'Ternaire / Optionnel'),
    _ProgChar('??', tooltip: 'Null coalescing'),
    _ProgChar('?.', tooltip: 'Optional chaining'),
  ],
  // Quotes & templates
  [
    _ProgChar('"', tooltip: 'Guillemet double'),
    _ProgChar("'", tooltip: 'Guillemet simple'),
    _ProgChar('`', tooltip: 'Backtick (template)'),
    _ProgChar('\${', tooltip: 'Template expression'),
    _ProgChar('"""', tooltip: 'Triple guillemets'),
  ],
  // Commentaires & divers
  [
    _ProgChar('//', tooltip: 'Commentaire ligne'),
    _ProgChar('/*', tooltip: 'Commentaire bloc ouv.'),
    _ProgChar('*/', tooltip: 'Commentaire bloc ferm.'),
    _ProgChar('/**', tooltip: 'Doc comment'),
    _ProgChar('#', tooltip: 'Dièse / Préprocesseur'),
    _ProgChar('@', tooltip: 'Décorateur / Annotation'),
    _ProgChar('\\', tooltip: 'Antislash'),
    _ProgChar('|', tooltip: 'Pipe'),
    _ProgChar('&', tooltip: 'And bit / Référence'),
    _ProgChar('~', tooltip: 'Tilde'),
    _ProgChar('%', tooltip: 'Modulo'),
    _ProgChar('!', tooltip: 'Not'),
  ],
];

// ---------------------------------------------------------------------------
// AzertyKeyboard — Widget principal
// ---------------------------------------------------------------------------

/// @class AzertyKeyboard
/// @brief Clavier AZERTY virtuel complet avec barre de programmation.
///
/// @param onKeyTap     Appelé avec le caractère à insérer.
/// @param onSpecialAction Appelé pour les actions non-imprimables.
/// @param textController Optionnel — pour lire le contexte (sélection, curseur).
class AzertyKeyboard extends StatefulWidget {
  /// Callback d'insertion d'un caractère imprimable.
  final void Function(String char) onKeyTap;

  /// Callback pour les actions spéciales (navigation, raccourcis).
  final void Function(KeyboardAction action) onSpecialAction;

  /// Contrôleur optionnel pour contexte curseur / sélection.
  final TextEditingController? textController;

  const AzertyKeyboard({
    super.key,
    required this.onKeyTap,
    required this.onSpecialAction,
    this.textController,
  });

  @override
  State<AzertyKeyboard> createState() => _AzertyKeyboardState();
}

class _AzertyKeyboardState extends State<AzertyKeyboard>
    with TickerProviderStateMixin {
  // --- État des modificateurs ---
  bool _shiftActive = false;
  bool _capsLock = false;
  bool _ctrlActive = false;
  bool _altActive = false;
  bool _altGrActive = false;

  // --- Onglet barre programmation ---
  int _progTabIndex = 0;

  // --- Animation du popup de touche ---
  OverlayEntry? _popupEntry;

  // ---------------------------------------------------------------------------
  // Résolution du label final d'une touche
  // ---------------------------------------------------------------------------

  /// @brief Retourne le label actif d'une [_KeyDef] selon les modificateurs.
  String _resolveLabel(_KeyDef key) {
    if (_altGrActive && key.altGr != null && key.altGr!.isNotEmpty) {
      return key.altGr!;
    }
    final isUpper = _shiftActive ^ _capsLock;
    if (isUpper) {
      if (key.shift != null) return key.shift!;
      if (key.base.length == 1 && RegExp(r'[a-z]').hasMatch(key.base)) {
        return key.base.toUpperCase();
      }
    }
    return key.base;
  }

  // ---------------------------------------------------------------------------
  // Gestion des appuis
  // ---------------------------------------------------------------------------

  /// @brief Traite l'appui sur une touche.
  void _handleKeyPress(_KeyDef key) {
    final label = _resolveLabel(key);

    // Touches de fonction
    switch (key.base) {
      case '⌫':
        widget.onSpecialAction(KeyboardAction.backspace);
        _resetTransientModifiers();
        return;
      case '↵':
        widget.onSpecialAction(KeyboardAction.enter);
        _resetTransientModifiers();
        return;
      case '⇥':
        widget.onSpecialAction(KeyboardAction.tab);
        _resetTransientModifiers();
        return;
      case '⇧':
        setState(() => _shiftActive = !_shiftActive);
        return;
      case '⇪':
        setState(() {
          _capsLock = !_capsLock;
          _shiftActive = false;
        });
        return;
      case 'Ctrl':
        setState(() => _ctrlActive = !_ctrlActive);
        return;
      case 'Alt':
        setState(() => _altActive = !_altActive);
        return;
      case 'AltGr':
        setState(() => _altGrActive = !_altGrActive);
        return;
      case '⊞': // Touche Win — ignorée ou custom
        return;
      case '←':
        widget.onSpecialAction(KeyboardAction.arrowLeft);
        _resetTransientModifiers();
        return;
      case '→':
        widget.onSpecialAction(KeyboardAction.arrowRight);
        _resetTransientModifiers();
        return;
      case '↑↓':
        // Affiche popup choix haut/bas
        // (pour simplicité on envoie Up par défaut; voir _showArrowPopup)
        _showArrowPopup();
        return;
    }

    // Raccourcis Ctrl
    if (_ctrlActive) {
      final lower = label.toLowerCase();
      final actions = {
        'c': KeyboardAction.ctrlC,
        'v': KeyboardAction.ctrlV,
        'x': KeyboardAction.ctrlX,
        'z': KeyboardAction.ctrlZ,
        'y': KeyboardAction.ctrlY,
        'a': KeyboardAction.ctrlA,
        's': KeyboardAction.ctrlS,
        'f': KeyboardAction.ctrlF,
      };
      if (actions.containsKey(lower)) {
        widget.onSpecialAction(actions[lower]!);
        setState(() => _ctrlActive = false);
        return;
      }
    }

    // Insertion d'un caractère imprimable
    if (label.isNotEmpty && label != '²') {
      widget.onKeyTap(label);
    }

    // Réinitialise Shift (mais pas CapsLock)
    if (_shiftActive) setState(() => _shiftActive = false);
    if (_altGrActive) setState(() => _altGrActive = false);
  }

  /// @brief Remet à zéro les modificateurs transitoires après insertion.
  void _resetTransientModifiers() {
    if (_shiftActive || _altActive || _altGrActive) {
      setState(() {
        _shiftActive = false;
        _altActive = false;
        _altGrActive = false;
      });
    }
  }

  // ---------------------------------------------------------------------------
  // Popup flèches haut/bas
  // ---------------------------------------------------------------------------

  /// @brief Affiche un menu popup pour choisir ↑ ou ↓.
  void _showArrowPopup() {
    // Trouve la position globale de la touche ↑↓ — fallback centre écran
    final overlay = Overlay.of(context);
    _popupEntry?.remove();
    _popupEntry = OverlayEntry(
      builder: (ctx) => Positioned(
        bottom: 220,
        left: 0,
        right: 0,
        child: Center(
          child: Material(
            elevation: 8,
            borderRadius: BorderRadius.circular(12),
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: IntrinsicWidth(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _arrowBtn('↑', () {
                    widget.onSpecialAction(KeyboardAction.arrowUp);
                    _closePopup();
                  }),
                  const Divider(height: 1),
                  _arrowBtn('↓', () {
                    widget.onSpecialAction(KeyboardAction.arrowDown);
                    _closePopup();
                  }),
                  const Divider(height: 1),
                  _arrowBtn('PgUp', () {
                    widget.onSpecialAction(KeyboardAction.pageUp);
                    _closePopup();
                  }),
                  const Divider(height: 1),
                  _arrowBtn('PgDn', () {
                    widget.onSpecialAction(KeyboardAction.pageDown);
                    _closePopup();
                  }),
                ],
              ),
            ),
          ),
        ),
      ),
    );
    overlay.insert(_popupEntry!);
  }

  Widget _arrowBtn(String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
        child: Text(
          label,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }

  void _closePopup() {
    _popupEntry?.remove();
    _popupEntry = null;
  }

  @override
  void dispose() {
    _closePopup();
    super.dispose();
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return GestureDetector(
      onTap: _closePopup,
      child: Container(
        decoration: BoxDecoration(
          color: isDark
              ? const Color(0xFF1A1D23)
              : const Color(0xFFD1D5DB),
          border: Border(
            top: BorderSide(
              color: isDark
                  ? const Color(0xFF2D3240)
                  : const Color(0xFFB0B8C8),
              width: 1,
            ),
          ),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // ── Barre d'outils de programmation ──
              _ProgrammingBar(
                groups: _progGroups,
                selectedGroup: _progTabIndex,
                onGroupChanged: (i) => setState(() => _progTabIndex = i),
                onCharTap: widget.onKeyTap,
                isDark: isDark,
              ),

              const SizedBox(height: 4),

              // ── Rangées de touches ──
              _KeyRow(
                keys: _row0,
                onPress: _handleKeyPress,
                resolveLabel: _resolveLabel,
                shiftActive: _shiftActive,
                capsLock: _capsLock,
                ctrlActive: _ctrlActive,
                altGrActive: _altGrActive,
                isDark: isDark,
              ),
              _KeyRow(
                keys: _row1,
                onPress: _handleKeyPress,
                resolveLabel: _resolveLabel,
                shiftActive: _shiftActive,
                capsLock: _capsLock,
                ctrlActive: _ctrlActive,
                altGrActive: _altGrActive,
                isDark: isDark,
              ),
              _KeyRow(
                keys: _row2,
                onPress: _handleKeyPress,
                resolveLabel: _resolveLabel,
                shiftActive: _shiftActive,
                capsLock: _capsLock,
                ctrlActive: _ctrlActive,
                altGrActive: _altGrActive,
                isDark: isDark,
              ),
              _KeyRow(
                keys: _row3,
                onPress: _handleKeyPress,
                resolveLabel: _resolveLabel,
                shiftActive: _shiftActive,
                capsLock: _capsLock,
                ctrlActive: _ctrlActive,
                altGrActive: _altGrActive,
                isDark: isDark,
              ),
              _KeyRow(
                keys: _row4,
                onPress: _handleKeyPress,
                resolveLabel: _resolveLabel,
                shiftActive: _shiftActive,
                capsLock: _capsLock,
                ctrlActive: _ctrlActive,
                altGrActive: _altGrActive,
                isDark: isDark,
                isBottomRow: true,
              ),

              const SizedBox(height: 4),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// _ProgrammingBar — barre de caractères de programmation
// ---------------------------------------------------------------------------

/// @class _ProgrammingBar
/// @brief En-tête avec onglets par catégorie + liste de caractères cliquables.
class _ProgrammingBar extends StatelessWidget {
  final List<List<_ProgChar>> groups;
  final int selectedGroup;
  final void Function(int) onGroupChanged;
  final void Function(String) onCharTap;
  final bool isDark;

  static const List<String> _groupLabels = [
    '{ }',
    '= ≠',
    '; .',
    '" \'',
    '// #',
  ];

  const _ProgrammingBar({
    required this.groups,
    required this.selectedGroup,
    required this.onGroupChanged,
    required this.onCharTap,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final accentColor = const Color(0xFF4FC3F7);
    final bgColor = isDark ? const Color(0xFF12151A) : const Color(0xFFBCC3CE);
    final tabBg = isDark ? const Color(0xFF1E2330) : const Color(0xFFC8D0DA);
    final activeTabBg =
        isDark ? const Color(0xFF263045) : const Color(0xFFFFFFFF);

    return Container(
      color: bgColor,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Onglets catégories ──
          SizedBox(
            height: 32,
            child: Row(
              children: List.generate(_groupLabels.length, (i) {
                final isSelected = i == selectedGroup;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => onGroupChanged(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 150),
                      decoration: BoxDecoration(
                        color: isSelected ? activeTabBg : tabBg,
                        border: Border(
                          bottom: BorderSide(
                            color: isSelected
                                ? accentColor
                                : Colors.transparent,
                            width: 2,
                          ),
                        ),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        _groupLabels[i],
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: isSelected
                              ? FontWeight.w700
                              : FontWeight.w400,
                          color: isSelected
                              ? accentColor
                              : (isDark
                                  ? Colors.white54
                                  : Colors.black45),
                          fontFamily: 'monospace',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),

          // ── Caractères du groupe actif ──
          SizedBox(
            height: 40,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              itemCount: groups[selectedGroup].length,
              itemBuilder: (ctx, i) {
                final pc = groups[selectedGroup][i];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: Tooltip(
                    message: pc.tooltip ?? pc.char,
                    child: _ProgCharButton(
                      char: pc.char,
                      onTap: () => onCharTap(pc.char),
                      isDark: isDark,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// @class _ProgCharButton
/// @brief Bouton d'un caractère de programmation avec animation de pression.
class _ProgCharButton extends StatefulWidget {
  final String char;
  final VoidCallback onTap;
  final bool isDark;

  const _ProgCharButton({
    required this.char,
    required this.onTap,
    required this.isDark,
  });

  @override
  State<_ProgCharButton> createState() => _ProgCharButtonState();
}

class _ProgCharButtonState extends State<_ProgCharButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 80),
    );
    _scale = Tween(begin: 1.0, end: 0.88).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scale,
      child: GestureDetector(
        onTapDown: (_) => _ctrl.forward(),
        onTapUp: (_) {
          widget.onTap();
          _ctrl.reverse();
        },
        onTapCancel: () => _ctrl.reverse(),
        child: Container(
          constraints: const BoxConstraints(minWidth: 36),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            color: widget.isDark
                ? const Color(0xFF2A3045)
                : const Color(0xFFFFFFFF),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: widget.isDark
                  ? const Color(0xFF3A4560)
                  : const Color(0xFFB0BBCC),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: widget.isDark ? 0.3 : 0.1),
                blurRadius: 2,
                offset: const Offset(0, 1),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            widget.char,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: const Color(0xFF4FC3F7),
              fontFamily: 'monospace',
              letterSpacing: -0.5,
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// _KeyRow — une rangée de touches
// ---------------------------------------------------------------------------

/// @class _KeyRow
/// @brief Rangée horizontale de touches du clavier.
class _KeyRow extends StatelessWidget {
  final List<_KeyDef> keys;
  final void Function(_KeyDef) onPress;
  final String Function(_KeyDef) resolveLabel;
  final bool shiftActive;
  final bool capsLock;
  final bool ctrlActive;
  final bool altGrActive;
  final bool isDark;
  final bool isBottomRow;

  const _KeyRow({
    required this.keys,
    required this.onPress,
    required this.resolveLabel,
    required this.shiftActive,
    required this.capsLock,
    required this.ctrlActive,
    required this.altGrActive,
    required this.isDark,
    this.isBottomRow = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
      child: Row(
        children: keys.map((key) {
          final isModifierActive = _isModifierKeyActive(key);
          return Expanded(
            flex: (key.widthFactor * 10).round(),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 1.5),
              child: _KeyButton(
                keyDef: key,
                label: resolveLabel(key),
                onPress: () => onPress(key),
                isActive: isModifierActive,
                isDark: isDark,
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  bool _isModifierKeyActive(_KeyDef key) {
    switch (key.base) {
      case '⇧':
        return shiftActive;
      case '⇪':
        return capsLock;
      case 'Ctrl':
        return ctrlActive;
      case 'AltGr':
        return altGrActive;
      default:
        return false;
    }
  }
}

// ---------------------------------------------------------------------------
// _KeyButton — une touche individuelle avec animation
// ---------------------------------------------------------------------------

/// @class _KeyButton
/// @brief Touche individuelle du clavier avec animation de pression et popup.
class _KeyButton extends StatefulWidget {
  final _KeyDef keyDef;
  final String label;
  final VoidCallback onPress;
  final bool isActive;
  final bool isDark;

  const _KeyButton({
    required this.keyDef,
    required this.label,
    required this.onPress,
    required this.isActive,
    required this.isDark,
  });

  @override
  State<_KeyButton> createState() => _KeyButtonState();
}

class _KeyButtonState extends State<_KeyButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _scaleAnim;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 70),
      reverseDuration: const Duration(milliseconds: 120),
    );
    _scaleAnim = Tween(begin: 1.0, end: 0.9).animate(
      CurvedAnimation(parent: _ctrl, curve: Curves.easeIn),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------------------
  // Couleurs selon l'état et le type
  // ---------------------------------------------------------------------------

  Color get _keyBackground {
    if (widget.isActive) {
      return widget.isDark
          ? const Color(0xFF1E4A8A)
          : const Color(0xFF90CAF9);
    }
    if (widget.keyDef.isFn) {
      return widget.isDark
          ? const Color(0xFF252A35)
          : const Color(0xFFB8C4D4);
    }
    return widget.isDark
        ? const Color(0xFF2E3448)
        : const Color(0xFFFFFFFF);
  }

  Color get _keyBorder {
    if (widget.isActive) return const Color(0xFF4FC3F7);
    return widget.isDark
        ? const Color(0xFF3D4560)
        : const Color(0xFFA0ACC0);
  }

  Color get _labelColor {
    if (widget.isActive) return const Color(0xFF4FC3F7);
    if (widget.keyDef.isFn) {
      return widget.isDark ? const Color(0xFFB0BDD0) : const Color(0xFF4A5568);
    }
    return widget.isDark ? const Color(0xFFE8EDF5) : const Color(0xFF1A2030);
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    final hasAltGr = widget.keyDef.altGr != null &&
        widget.keyDef.altGr!.isNotEmpty;
    final hasShift = widget.keyDef.shift != null &&
        widget.keyDef.shift!.isNotEmpty &&
        widget.keyDef.shift != widget.keyDef.base.toUpperCase();

    return ScaleTransition(
      scale: _scaleAnim,
      child: GestureDetector(
        onTapDown: (_) {
          setState(() => _pressed = true);
          _ctrl.forward();
        },
        onTapUp: (_) {
          setState(() => _pressed = false);
          widget.onPress();
          _ctrl.reverse();
        },
        onTapCancel: () {
          setState(() => _pressed = false);
          _ctrl.reverse();
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 80),
          height: 40,
          decoration: BoxDecoration(
            color: _pressed
                ? (_keyBackground.withValues(alpha: 0.7))
                : _keyBackground,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(color: _keyBorder, width: 1),
            boxShadow: _pressed
                ? []
                : [
                    BoxShadow(
                      color: Colors.black
                          .withValues(alpha: widget.isDark ? 0.4 : 0.15),
                      blurRadius: 0,
                      offset: const Offset(0, 2),
                    ),
                  ],
          ),
          child: Stack(
            children: [
              // ── AltGr label (coin haut-droit) ──
              if (hasAltGr)
                Positioned(
                  top: 2,
                  right: 3,
                  child: Text(
                    widget.keyDef.altGr!,
                    style: TextStyle(
                      fontSize: 7,
                      color: const Color(0xFF4FC3F7).withValues(alpha: 0.7),
                      fontFamily: 'monospace',
                      height: 1,
                    ),
                  ),
                ),

              // ── Shift label (coin haut-gauche) ──
              if (hasShift)
                Positioned(
                  top: 2,
                  left: 3,
                  child: Text(
                    widget.keyDef.shift!,
                    style: TextStyle(
                      fontSize: 7,
                      color: widget.isDark
                          ? Colors.white38
                          : Colors.black38,
                      height: 1,
                    ),
                  ),
                ),

              // ── Label principal centré ──
              Center(
                child: Text(
                  widget.label,
                  style: TextStyle(
                    fontSize: widget.keyDef.isFn ? 11 : 13,
                    fontWeight: widget.keyDef.isFn
                        ? FontWeight.w600
                        : FontWeight.w500,
                    color: _labelColor,
                    fontFamily:
                        widget.keyDef.isFn ? null : 'monospace',
                    height: 1,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.clip,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Intégration avec TextEditingController (helpers)
// ---------------------------------------------------------------------------

/// @class KeyboardController
/// @brief Helpers pour connecter [AzertyKeyboard] à un [TextEditingController].
///
/// Usage dans votre State :
/// ```dart
/// KeyboardController.handleKeyTap(controller, char);
/// KeyboardController.handleSpecialAction(controller, action);
/// ```
class KeyboardController {
  KeyboardController._();

  /// @brief Insère [char] à la position du curseur dans [ctrl].
  static void handleKeyTap(TextEditingController ctrl, String char) {
    final text = ctrl.text;
    final sel = ctrl.selection;
    if (!sel.isValid) {
      ctrl.text = text + char;
      ctrl.selection = TextSelection.collapsed(offset: ctrl.text.length);
      return;
    }
    final newText = text.replaceRange(sel.start, sel.end, char);
    final newOffset = sel.start + char.length;
    ctrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: newOffset),
    );
  }

  /// @brief Applique une [KeyboardAction] au [TextEditingController].
  static void handleSpecialAction(
    TextEditingController ctrl,
    KeyboardAction action,
  ) {
    final text = ctrl.text;
    final sel = ctrl.selection;
    final offset = sel.isValid ? sel.baseOffset : text.length;

    switch (action) {
      case KeyboardAction.backspace:
        if (!sel.isValid || text.isEmpty) return;
        if (!sel.isCollapsed) {
          // Supprime la sélection
          final newText = text.replaceRange(sel.start, sel.end, '');
          ctrl.value = TextEditingValue(
            text: newText,
            selection: TextSelection.collapsed(offset: sel.start),
          );
        } else if (offset > 0) {
          final newText =
              text.substring(0, offset - 1) + text.substring(offset);
          ctrl.value = TextEditingValue(
            text: newText,
            selection: TextSelection.collapsed(offset: offset - 1),
          );
        }
        break;

      case KeyboardAction.enter:
        handleKeyTap(ctrl, '\n');
        break;

      case KeyboardAction.tab:
        handleKeyTap(ctrl, '  '); // 2 espaces
        break;

      case KeyboardAction.arrowLeft:
        if (offset > 0) {
          ctrl.selection = TextSelection.collapsed(offset: offset - 1);
        }
        break;

      case KeyboardAction.arrowRight:
        if (offset < text.length) {
          ctrl.selection = TextSelection.collapsed(offset: offset + 1);
        }
        break;

      case KeyboardAction.arrowUp:
        _moveCursorVertical(ctrl, -1);
        break;

      case KeyboardAction.arrowDown:
        _moveCursorVertical(ctrl, 1);
        break;

      case KeyboardAction.home:
        final lineStart = text.lastIndexOf('\n', offset - 1);
        ctrl.selection = TextSelection.collapsed(
          offset: lineStart == -1 ? 0 : lineStart + 1,
        );
        break;

      case KeyboardAction.end:
        final lineEnd = text.indexOf('\n', offset);
        ctrl.selection = TextSelection.collapsed(
          offset: lineEnd == -1 ? text.length : lineEnd,
        );
        break;

      case KeyboardAction.pageUp:
        ctrl.selection = const TextSelection.collapsed(offset: 0);
        break;

      case KeyboardAction.pageDown:
        ctrl.selection = TextSelection.collapsed(offset: text.length);
        break;

      case KeyboardAction.ctrlA:
        ctrl.selection =
            TextSelection(baseOffset: 0, extentOffset: text.length);
        break;

      case KeyboardAction.ctrlZ:
      // Undo géré par le parent (history)
      case KeyboardAction.ctrlY:
      // Redo géré par le parent (history)
      case KeyboardAction.ctrlC:
      case KeyboardAction.ctrlX:
      case KeyboardAction.ctrlV:
      case KeyboardAction.ctrlS:
      case KeyboardAction.ctrlF:
      case KeyboardAction.escape:
        // Ces actions sont gérées par le parent
        break;
    }
  }

  /// @brief Déplace le curseur verticalement de [delta] lignes.
  static void _moveCursorVertical(
    TextEditingController ctrl,
    int delta,
  ) {
    final text = ctrl.text;
    final offset =
        ctrl.selection.isValid ? ctrl.selection.baseOffset : text.length;

    // Trouve le début de la ligne courante
    final lineStart =
        (text.lastIndexOf('\n', offset > 0 ? offset - 1 : 0) + 1);
    final colInLine = offset - lineStart;

    if (delta < 0) {
      // Aller en haut
      if (lineStart == 0) return; // Déjà sur la première ligne
      final prevLineEnd = lineStart - 1;
      final prevLineStart =
          (text.lastIndexOf('\n', prevLineEnd > 0 ? prevLineEnd - 1 : 0) + 1);
      final prevLineLen = prevLineEnd - prevLineStart;
      ctrl.selection = TextSelection.collapsed(
        offset: prevLineStart + colInLine.clamp(0, prevLineLen),
      );
    } else {
      // Aller en bas
      final nextLineStart = text.indexOf('\n', offset);
      if (nextLineStart == -1) return; // Déjà sur la dernière ligne
      final nextLineEnd = text.indexOf('\n', nextLineStart + 1);
      final nextLineLen = nextLineEnd == -1
          ? text.length - nextLineStart - 1
          : nextLineEnd - nextLineStart - 1;
      ctrl.selection = TextSelection.collapsed(
        offset: nextLineStart + 1 + colInLine.clamp(0, nextLineLen),
      );
    }
  }
}
