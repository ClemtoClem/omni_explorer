
/// @file code_editor_screen.dart
/// @brief Editeur de code avec coloration syntaxique, terminal et runner.

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// re_editor 0.8.0
import 'package:re_editor/re_editor.dart';
// re_highlight 0.0.3 — styles avec tirets dans le nom du fichier
import 'package:re_highlight/styles/atom-one-dark.dart';
import 'package:re_highlight/styles/atom-one-light.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';

import '../../../app/theme/app_theme.dart';
import '../../../core/utils/file_utils.dart';
import '../../../core/services/settings_service.dart';
import '../languages/language_registry.dart';
import '../widgets/terminal_panel.dart';
import '../widgets/project_tree.dart';
import '../../../widgets/custom_keyboard/custom_keyboard.dart';

/// @class CodeEditorScreen
/// @brief Ecran éditeur de code avec onglets, terminal intégré et runner.
class CodeEditorScreen extends StatefulWidget {
  final String path;
  const CodeEditorScreen({super.key, required this.path});

  @override
  State<CodeEditorScreen> createState() => _CodeEditorScreenState();
}

class _CodeEditorScreenState extends State<CodeEditorScreen>
    with TickerProviderStateMixin {

  late CodeLineEditingController _editorCtrl;
  final FocusNode _focusNode = FocusNode();

  final List<_OpenFile> _openFiles = [];
  int _activeTab = 0;

  bool   _isProject    = false;
  String _projectRoot  = '';
  bool   _showTree     = true;
  bool   _showTerminal = false;
  bool   _showSearch   = false;

  List<String> _terminalOutput = [];
  Process?     _runProcess;

  final _searchCtrl  = TextEditingController();
  final _replaceCtrl = TextEditingController();

  bool get _canSave =>
      _openFiles.isNotEmpty && _openFiles[_activeTab].isDirty;

  @override
  void initState() {
    super.initState();
    // Masque la barre de navigation Android pour maximiser l'espace.
    SystemChrome.setEnabledSystemUIMode(
        SystemUiMode.manual, overlays: [SystemUiOverlay.top]);
        
    LanguageRegistry.instance.initDefaults();
    _editorCtrl = CodeLineEditingController();

    final isDir = FileSystemEntity.isDirectorySync(widget.path);
    if (isDir) {
      _isProject   = true;
      _projectRoot = widget.path;
    } else {
      _openFile(widget.path);
    }
  }

  @override
  void dispose() {
    // Restaure la barre de navigation Android.
    SystemChrome.setEnabledSystemUIMode(
        SystemUiMode.manual, overlays: SystemUiOverlay.values);
    _editorCtrl.dispose();
    _focusNode.dispose();
    _searchCtrl.dispose();
    _replaceCtrl.dispose();
    _runProcess?.kill();
    super.dispose();
  }

  // ── Gestion fichiers ──────────────────────────────────────────────────────

  Future<void> _openFile(String filePath) async {
    final idx = _openFiles.indexWhere((f) => f.path == filePath);
    if (idx >= 0) {
      setState(() {
        _activeTab  = idx;
        _editorCtrl = CodeLineEditingController.fromText(_openFiles[idx].content);
      });
      return;
    }
    try {
      final content = await File(filePath).readAsString();
      final lang    = LanguageRegistry.instance.forExtension(FileUtils.extOf(filePath));
      setState(() {
        _openFiles.add(_OpenFile(path: filePath, content: content, lang: lang));
        _activeTab  = _openFiles.length - 1;
        _editorCtrl = CodeLineEditingController.fromText(content);
      });
      context.read<SettingsService>().addRecentFile(filePath);
    } catch (e) {
      _showError('Impossible d\'ouvrir : $e');
    }
  }

  Future<void> _saveCurrentFile() async {
    if (_openFiles.isEmpty) return;
    final file = _openFiles[_activeTab];
    try {
      await File(file.path).writeAsString(_editorCtrl.text);
      setState(() {
        _openFiles[_activeTab] =
            file.copyWith(content: _editorCtrl.text, isDirty: false);
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Fichier sauvegardé'),
            duration: Duration(seconds: 1),
          ),
        );
      }
    } catch (e) {
      _showError('Erreur sauvegarde : $e');
    }
  }

  void _closeTab(int idx) {
    if (_openFiles[idx].isDirty) { _showSaveDialog(idx); return; }
    setState(() {
      _openFiles.removeAt(idx);
      if (_activeTab >= _openFiles.length) _activeTab = _openFiles.length - 1;
      _editorCtrl = _openFiles.isNotEmpty
          ? CodeLineEditingController.fromText(_openFiles[_activeTab].content)
          : CodeLineEditingController();
    });
  }

  void _showSaveDialog(int idx) async {
    final result = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Modifications non sauvegardées'),
        content: Text('Sauvegarder "${p.basename(_openFiles[idx].path)}" ?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, 'discard'),
            child: const Text('Abandonner'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, 'cancel'),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, 'save'),
            child: const Text('Sauvegarder'),
          ),
        ],
      ),
    );
    if (result == 'save') {
      await _saveCurrentFile();
      _closeTab(idx);
    } else if (result == 'discard') {
      setState(() {
        _openFiles.removeAt(idx);
        if (_activeTab >= _openFiles.length) _activeTab = _openFiles.length - 1;
        if (_openFiles.isNotEmpty) {
          _editorCtrl =
              CodeLineEditingController.fromText(_openFiles[_activeTab].content);
        }
      });
    }
  }

  // ── Exécution ─────────────────────────────────────────────────────────────

  Future<void> _runCurrentFile() async {
    if (_openFiles.isEmpty) return;
    final file = _openFiles[_activeTab];
    if (file.lang == null || !file.lang!.isRunnable) {
      _showError('Ce langage ne supporte pas l\'exécution directe.');
      return;
    }
    if (file.isDirty) await _saveCurrentFile();

    setState(() {
      _showTerminal = true;
      _terminalOutput = [
        '> ${file.lang!.runCommand} ${p.basename(file.path)}',
        '',
      ];
    });

    try {
      _runProcess = await Process.start(
        file.lang!.runCommand!,
        [...file.lang!.runArgs, file.path],
        workingDirectory:
            _isProject ? _projectRoot : p.dirname(file.path),
      );
      _runProcess!.stdout
          .transform(const SystemEncoding().decoder)
          .listen((d) {
        if (mounted) setState(() => _terminalOutput.addAll(d.split('\n')));
      });
      _runProcess!.stderr
          .transform(const SystemEncoding().decoder)
          .listen((d) {
        if (mounted) setState(() => _terminalOutput.addAll(d.split('\n')));
      });
      _runProcess!.exitCode.then((code) {
        if (mounted) {
          setState(() => _terminalOutput.add('\n> Terminé (code $code)'));
        }
      });
    } catch (e) {
      setState(() => _terminalOutput.add('Erreur : $e'));
    }
  }

  void _stopProcess() {
    _runProcess?.kill();
    _runProcess = null;
    setState(() => _terminalOutput.add('\n> Processus arrêté'));
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final theme  = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: _buildAppBar(theme),
      body: Column(
        children: [
          if (_openFiles.isNotEmpty) _buildTabBar(theme),
          Expanded(
            child: Row(
              children: [
                if (_isProject && _showTree)
                  ProjectTree(
                    rootPath:       _projectRoot,
                    onFileSelected: _openFile,
                    activeFile: _openFiles.isNotEmpty
                        ? _openFiles[_activeTab].path
                        : null,
                  ),
                Expanded(
                  child: Column(
                    children: [
                      if (_showSearch) _buildSearchBar(theme),
                      Expanded(child: _buildEditor(theme, isDark)),
                      if (_showTerminal)
                        TerminalPanel(
                          output:  _terminalOutput,
                          onClear: () =>
                              setState(() => _terminalOutput.clear()),
                          onClose: () =>
                              setState(() => _showTerminal = false),
                          onStop:  _runProcess != null ? _stopProcess : null,
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          CustomKeyboard(focusNode: _focusNode),
        ],
      ),
    );
  }

  // ── AppBar ────────────────────────────────────────────────────────────────

  AppBar _buildAppBar(ThemeData theme) {
    final file = _openFiles.isNotEmpty ? _openFiles[_activeTab] : null;
    return AppBar(
      leading: _isProject
          ? IconButton(
              icon: Icon(_showTree
                  ? Icons.view_sidebar_rounded
                  : Icons.view_sidebar_outlined),
              iconSize: 20,
              onPressed: () => setState(() => _showTree = !_showTree),
            )
          : null,
      title: Text(
        file != null
            ? p.basename(file.path) + (file.isDirty ? ' •' : '')
            : (_isProject ? p.basename(_projectRoot) : 'Editeur'),
        overflow: TextOverflow.ellipsis,
        style: theme.textTheme.titleMedium,
      ),
      actions: [
        if (file?.lang != null)
          Container(
            margin: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: file!.lang!.color.withValues(alpha:0.15),
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(file.lang!.label,
                style: TextStyle(fontSize: 10, color: file.lang!.color)),
          ),
        IconButton(
          icon:     const Icon(Icons.search_rounded),
          onPressed: () => setState(() => _showSearch = !_showSearch),
        ),
        IconButton(
          icon:     const Icon(Icons.save_rounded),
          tooltip:  'Sauvegarder',
          onPressed: _canSave ? _saveCurrentFile : null,
        ),
        if (file?.lang?.isRunnable == true)
          IconButton(
            icon:     const Icon(Icons.play_arrow_rounded),
            color:    AppColors.success,
            tooltip:  'Exécuter',
            onPressed: _runCurrentFile,
          ),
        IconButton(
          icon:     const Icon(Icons.terminal_rounded),
          tooltip:  'Terminal',
          onPressed: () => setState(() => _showTerminal = !_showTerminal),
        ),
      ],
    );
  }

  // ── Onglets ───────────────────────────────────────────────────────────────

  Widget _buildTabBar(ThemeData theme) {
    return Container(
      height: 36,
      color: theme.colorScheme.surface,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: _openFiles.length,
        itemBuilder: (_, i) {
          final f        = _openFiles[i];
          final isActive = i == _activeTab;
          return GestureDetector(
            onTap: () => setState(() {
              _activeTab  = i;
              _editorCtrl =
                  CodeLineEditingController.fromText(_openFiles[i].content);
            }),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                color: isActive
                    ? theme.scaffoldBackgroundColor
                    : Colors.transparent,
                border: Border(
                  bottom: BorderSide(
                    color: isActive ? AppColors.accent : Colors.transparent,
                    width: 2,
                  ),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    p.basename(f.path) + (f.isDirty ? ' •' : ''),
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: isActive
                          ? null
                          : theme.textTheme.bodySmall?.color,
                    ),
                  ),
                  const SizedBox(width: 6),
                  GestureDetector(
                    onTap: () => _closeTab(i),
                    child: const Icon(Icons.close_rounded, size: 14),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ── Editeur ───────────────────────────────────────────────────────────────

  Widget _buildEditor(ThemeData theme, bool isDark) {
    if (_openFiles.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.code_rounded,
                size: 64,
                color: theme.iconTheme.color?.withValues(alpha:0.15)),
            const SizedBox(height: 12),
            Text('Ouvrir un fichier pour commencer',
                style: theme.textTheme.bodyMedium
                    ?.copyWith(color: theme.textTheme.bodySmall?.color)),
          ],
        ),
      );
    }

    final file = _openFiles[_activeTab];
    final lang = file.lang;

    // re_highlight 0.0.3 : les thèmes sont des Map<String, TextStyle>
    // atomOneDarkTheme et atomOneLightTheme viennent des imports ci-dessus
    final codeTheme = CodeHighlightTheme(
      languages: {
        if (lang != null)
          lang.id: CodeHighlightThemeMode(mode: lang.highlightMode),
      },
      theme: isDark ? atomOneDarkTheme : atomOneLightTheme,
    );

    return CodeEditor(
      controller: _editorCtrl,
      focusNode:  _focusNode,
      onChanged:  (_) {
        if (_openFiles.isNotEmpty && !_openFiles[_activeTab].isDirty) {
          setState(() {
            _openFiles[_activeTab] =
                _openFiles[_activeTab].copyWith(isDirty: true);
          });
        }
      },
      // les numéros de ligne sont configurés via indicatorBuilder
      style: CodeEditorStyle(
        fontSize:        13,
        fontFamily:      'JetBrainsMono',
        backgroundColor: theme.scaffoldBackgroundColor,
        textColor:       theme.textTheme.bodyLarge?.color ?? Colors.white,
        cursorColor:     AppColors.accent,
        selectionColor:  AppColors.accent.withValues(alpha:0.3),
        codeTheme:       codeTheme,
      ),
      wordWrap: true,
      shortcutsActivatorsBuilder: DefaultCodeShortcutsActivatorsBuilder(),
    );
  }

  // ── Recherche / Remplacement ──────────────────────────────────────────────

  Widget _buildSearchBar(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      color: theme.colorScheme.surface,
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(
                hintText: 'Rechercher...',
                isDense: true,
                prefixIcon: Icon(Icons.search_rounded, size: 16),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _replaceCtrl,
              decoration: const InputDecoration(
                hintText: 'Remplacer...',
                isDense: true,
                prefixIcon: Icon(Icons.find_replace_rounded, size: 16),
              ),
            ),
          ),
          const SizedBox(width: 8),
          TextButton(
            onPressed: _replaceNext,
            child: const Text('Remplacer', style: TextStyle(fontSize: 12)),
          ),
          IconButton(
            icon: const Icon(Icons.close_rounded, size: 16),
            onPressed: () => setState(() => _showSearch = false),
          ),
        ],
      ),
    );
  }

  void _replaceNext() {
    final q = _searchCtrl.text;
    final r = _replaceCtrl.text;
    if (q.isEmpty || _openFiles.isEmpty) return;
    final newText = _editorCtrl.text.replaceFirst(q, r);
    setState(() {
      _openFiles[_activeTab] =
          _openFiles[_activeTab].copyWith(content: newText, isDirty: true);
      _editorCtrl = CodeLineEditingController.fromText(newText);
    });
  }

  void _showError(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(msg), backgroundColor: AppColors.error),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

/// @class _OpenFile
/// @brief Fichier ouvert dans un onglet de l'éditeur.
class _OpenFile {
  final String             path;
  final String             content;
  final LanguageDefinition? lang;
  final bool               isDirty;

  const _OpenFile({
    required this.path,
    required this.content,
    this.lang,
    this.isDirty = false,
  });

  _OpenFile copyWith({String? content, bool? isDirty}) => _OpenFile(
    path:    path,
    content: content ?? this.content,
    lang:    lang,
    isDirty: isDirty ?? this.isDirty,
  );
}
