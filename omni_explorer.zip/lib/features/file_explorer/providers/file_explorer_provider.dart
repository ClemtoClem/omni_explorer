/// @file file_explorer_provider.dart
/// @brief Provider de l'explorateur de fichiers (navigation, tri, filtre).
///
/// Gère l'historique de navigation (undo/redo), le chargement des entrées
/// d'un répertoire, le tri, le filtrage et la sélection multiple.

import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../app/constants/app_constants.dart';
import '../../../core/models/file_item.dart';
import '../../../core/services/settings_service.dart';
import 'dart:developer' as developer;

/// @class FileExplorerProvider
/// @brief Provider principal de l'explorateur de fichiers.
class FileExplorerProvider extends ChangeNotifier {
  final SettingsService _settings;

  FileExplorerProvider(this._settings) {
    _settings.addListener(_onSettingsChanged);
  }

  // ── État de navigation ────────────────────────────────────────────────────
  String       _currentPath  = '';
  final List<String> _history    = [];   // Historique undo
  final List<String> _redoStack  = [];   // Pile redo
  List<FileItem>     _entries    = [];
  List<FileItem>?    _cachedEntries;     // Cache des entrées filtrées/triées
  bool               _loading    = false;
  String?            _error;
  bool               _needsFullStoragePermission = false;

  // ── Sélection ─────────────────────────────────────────────────────────────
  final Set<String>  _selected   = {};
  bool               _selectMode = false;

  // ── Filtre ────────────────────────────────────────────────────────────────
  String        _filterQuery     = '';
  FileCategory? _filterCategory;

  // ── Getters ───────────────────────────────────────────────────────────────
  String         get currentPath    => _currentPath;
  bool           get loading        => _loading;
  String?        get error          => _error;
  bool           get selectMode     => _selectMode;
  Set<String>    get selected       => Set.unmodifiable(_selected);
  String         get filterQuery    => _filterQuery;
  FileCategory?  get filterCategory => _filterCategory;
  bool           get canUndo        => _history.isNotEmpty;
  bool           get canRedo        => _redoStack.isNotEmpty;
  bool           get needsFullStoragePermission => _needsFullStoragePermission;

  /// Segments du chemin pour la barre de navigation interactive.
  List<String> get pathSegments {
    if (_currentPath.isEmpty) return [];
    return _currentPath.split('/').where((s) => s.isNotEmpty).toList();
  }

  /// Entrées filtrées et triées (résultat mis en cache).
  List<FileItem> get entries => _cachedEntries ??= _buildEntries();

  List<FileItem> _buildEntries() {
    final q = _filterQuery.isEmpty ? null : _filterQuery.toLowerCase();

    final list = _entries.where((f) {
      if (!_settings.showHidden && f.isHidden) return false;
      if (q != null && !f.name.toLowerCase().contains(q)) return false;
      if (_filterCategory != null && f.category != _filterCategory) return false;
      return true;
    }).toList();

    list.sort((a, b) {
      if (a.isDirectory != b.isDirectory) return a.isDirectory ? -1 : 1;
      int cmp;
      switch (_settings.sortMode) {
        case SortMode.name: cmp = a.name.toLowerCase().compareTo(b.name.toLowerCase());
        case SortMode.date: cmp = a.modified.compareTo(b.modified);
        case SortMode.size: cmp = a.size.compareTo(b.size);
        case SortMode.type: cmp = a.extension.compareTo(b.extension);
      }
      return _settings.sortAsc ? cmp : -cmp;
    });

    return list;
  }

  void _invalidateCache() {
    _cachedEntries = null;
  }

  // ── Initialisation ────────────────────────────────────────────────────────

  /// @brief Initialise l'explorateur en vérifiant les permissions et en naviguant vers le stockage racine.
  Future<void> init() async {
    await _requestPermissions();
    final root = await _getRootPath();
    await navigateTo(root, addToHistory: false);
  }

  Future<void> _requestPermissions() async {
    if (!Platform.isAndroid) return;

    // Requête groupée via l'extension List<Permission>.request() : la plateforme
    // présente un unique dialog système et ignore les permissions non applicables
    // à la version SDK courante. Évite les conflits de Future.wait() qui pouvaient
    // provoquer des refus silencieux quand plusieurs dialogs se télescopaient.
    await [
      Permission.photos,
      Permission.videos,
      Permission.audio,
      Permission.storage,
    ].request();

    if (!await Permission.accessMediaLocation.isGranted) {
      await Permission.accessMediaLocation.request();
    }

    if (!await Permission.locationAlways.isGranted) {
      await Permission.locationAlways.request();
    }

    // MANAGE_EXTERNAL_STORAGE doit être demandée séparément car sur Android 11+
    // elle redirige vers l'écran Paramètres système (pas une dialog inline).
    if (!await Permission.manageExternalStorage.isGranted) {
      await Permission.manageExternalStorage.request();
    }

    _needsFullStoragePermission =
        !await Permission.manageExternalStorage.isGranted;
    if (_needsFullStoragePermission) notifyListeners();
  }

  /// Re-vérifie les permissions au retour des Paramètres système.
  /// Si MANAGE_EXTERNAL_STORAGE vient d'être accordée, ré-initialise
  /// l'explorateur sans redemander les permissions déjà acquises.
  Future<void> recheckAndInit() async {
    if (!Platform.isAndroid) return;
    final wasBlocked = _needsFullStoragePermission;
    _needsFullStoragePermission =
        !await Permission.manageExternalStorage.isGranted;

    if (wasBlocked && !_needsFullStoragePermission) {
      // Permission nouvellement accordée → ré-initialiser le chemin racine.
      final root = await _getRootPath();
      await navigateTo(root, addToHistory: false);
    } else if (wasBlocked != _needsFullStoragePermission) {
      notifyListeners();
    }
  }

  Future<String> _getRootPath() async {
    if (Platform.isAndroid) {
      try {
        final dirs = await getExternalStorageDirectories();
        if (dirs != null && dirs.isNotEmpty) {
          // Remonter jusqu'à la racine du stockage (ex: /storage/emulated/0)
          var dir = dirs.first;
          var path = dir.path;
          while (path.contains('/Android')) {
            path = p.dirname(path);
          }
          return path;
        }
      } catch (_) {}
    }
    final dir = await getApplicationDocumentsDirectory();
    return dir.path;
  }

  // ── Navigation ────────────────────────────────────────────────────────────

  /// @brief Navigue vers un répertoire.
  /// @param path         Chemin absolu de destination.
  /// @param addToHistory Si vrai, ajoute le chemin actuel à l'historique undo.
  Future<void> navigateTo(String path, {bool addToHistory = true}) async {
    if (path == _currentPath) return;
    if (addToHistory && _currentPath.isNotEmpty) {
      _history.add(_currentPath);
      if (_history.length > AppConstants.maxUndoHistory) _history.removeAt(0);
      _redoStack.clear();
    }
    _currentPath = path;
    _selected.clear();
    _selectMode = false;
    await _loadEntries();
  }

  /// @brief Remonte au répertoire parent.
  Future<void> navigateUp() async {
    if (_currentPath.isEmpty || _currentPath == '/') return;
    final parent = p.dirname(_currentPath);
    if (parent != _currentPath) await navigateTo(parent);
  }

  /// @brief Annule la dernière navigation (undo).
  Future<void> undo() async {
    if (!canUndo) return;
    _redoStack.add(_currentPath);
    final prev = _history.removeLast();
    _currentPath = prev;
    _selected.clear();
    _selectMode = false;
    await _loadEntries();
  }

  /// @brief Refait la navigation annulée (redo).
  Future<void> redo() async {
    if (!canRedo) return;
    _history.add(_currentPath);
    final next = _redoStack.removeLast();
    _currentPath = next;
    _selected.clear();
    _selectMode = false;
    await _loadEntries();
  }

  /// @brief Navigue vers un segment de chemin (clic sur barre de navigation).
  Future<void> navigateToSegment(int segmentIndex) async {
    final segs = pathSegments;
    if (segmentIndex >= segs.length) return;
    final newPath = '/${segs.sublist(0, segmentIndex + 1).join('/')}';
    await navigateTo(newPath);
  }

  // ── Chargement du répertoire ──────────────────────────────────────────────

  Future<void> _loadEntries() async {
    _loading = true;
    _error   = null;
    notifyListeners();

    try {
      final dir = Directory(_currentPath);
      if (!dir.existsSync()) {
        _error = 'Répertoire introuvable : $_currentPath';
        _entries = [];
      } else {
        final entities = await dir.list().toList();
        final futures = entities.map((e) async {
          try {
            return await FileItem.fromEntity(e);
          } catch (_) {
            return null;
          }
        }).toList();
        final results = await Future.wait(futures);
        _entries = results.whereType<FileItem>().toList();
        developer.log(
          'Entries loaded: ${_entries.length}',
        );
        for (final entry in _entries) {
          developer.log(entry.toStringDebug());
        }
      }
    } catch (e) {
      _error   = e.toString();
      _entries = [];
    }

    _loading = false;
    _invalidateCache();
    notifyListeners();
  }

  /// @brief Recharge le répertoire courant.
  Future<void> refresh() => _loadEntries();

  // ── Filtre ────────────────────────────────────────────────────────────────

  void setFilterQuery(String q) {
    _filterQuery = q;
    _invalidateCache();
    notifyListeners();
  }

  void setFilterCategory(FileCategory? cat) {
    _filterCategory = cat;
    _invalidateCache();
    notifyListeners();
  }

  void clearFilter() {
    _filterQuery    = '';
    _filterCategory = null;
    _invalidateCache();
    notifyListeners();
  }

  // ── Sélection ─────────────────────────────────────────────────────────────

  void toggleSelectMode() {
    _selectMode = !_selectMode;
    if (!_selectMode) _selected.clear();
    notifyListeners();
  }

  void toggleSelect(String path) {
    if (_selected.contains(path)) {
      _selected.remove(path);
    } else {
      _selected.add(path);
    }
    if (_selected.isEmpty) _selectMode = false;
    notifyListeners();
  }

  void selectAll() {
    _selected.addAll(entries.map((e) => e.path));
    notifyListeners();
  }

  void clearSelection() {
    _selected.clear();
    _selectMode = false;
    notifyListeners();
  }

  // ── Opérations sur fichiers ───────────────────────────────────────────────

  /// @brief Crée un nouveau répertoire dans le répertoire courant.
  Future<void> createDirectory(String name) async {
    final newDir = Directory(p.join(_currentPath, name));
    if (!newDir.existsSync()) await newDir.create();
    await _loadEntries();
  }

  /// @brief Crée un nouveau fichier vide dans le répertoire courant.
  Future<void> createFile(String name) async {
    final newFile = File(p.join(_currentPath, name));
    if (!newFile.existsSync()) await newFile.create();
    await _loadEntries();
  }

  /// @brief Renomme un fichier ou répertoire.
  Future<void> rename(String oldPath, String newName) async {
    final newPath = p.join(p.dirname(oldPath), newName);
    final type = FileSystemEntity.typeSync(oldPath);
    if (type == FileSystemEntityType.directory) {
      await Directory(oldPath).rename(newPath);
    } else {
      await File(oldPath).rename(newPath);
    }
    await _loadEntries();
  }

  /// @brief Copie un fichier ou répertoire dans le répertoire courant.
  Future<void> copyTo(String sourcePath, String destDir) async {
    final name = p.basename(sourcePath);
    final dest = p.join(destDir, name);
    final type = FileSystemEntity.typeSync(sourcePath);
    if (type == FileSystemEntityType.file) {
      await File(sourcePath).copy(dest);
    } else {
      await _copyDirectory(Directory(sourcePath), Directory(dest));
    }
    await _loadEntries();
  }

  Future<void> _copyDirectory(Directory src, Directory dst) async {
    await dst.create(recursive: true);
    await for (final e in src.list()) {
      if (e is File) {
        await e.copy(p.join(dst.path, p.basename(e.path)));
      } else if (e is Directory) {
        await _copyDirectory(e, Directory(p.join(dst.path, p.basename(e.path))));
      }
    }
  }

  // ── Stockages externes ────────────────────────────────────────────────────

  /// @brief Retourne la liste des chemins de stockage disponibles (interne + SD).
  Future<List<Map<String, String>>> getStorages() async {
    final result = <Map<String, String>>[];

    if (Platform.isAndroid) {
      try {
        final dirs = await getExternalStorageDirectories();
        if (dirs != null) {
          for (int i = 0; i < dirs.length; i++) {
            var path = dirs[i].path;
            while (path.contains('/Android')) { path = p.dirname(path); }
            result.add({
              'name': i == 0 ? 'Stockage interne' : 'Carte SD $i',
              'path': path,
            });
          }
        }
      } catch (_) {}
    }

    if (result.isEmpty) {
      final dir = await getApplicationDocumentsDirectory();
      result.add({'name': 'Documents', 'path': dir.path});
    }

    return result;
  }

  // ── Cleanup ───────────────────────────────────────────────────────────────

  void _onSettingsChanged() {
    _invalidateCache();
    notifyListeners();
  }

  @override
  void dispose() {
    _settings.removeListener(_onSettingsChanged);
    super.dispose();
  }
}
