/// @file file_explorer_screen.dart
/// @brief Écran principal de l'explorateur de fichiers.
///
/// Affiche le contenu d'un répertoire avec navigation interactive,
/// barre de chemin éditable, filtres, tri, et sélection multiple.
/// L'ouverture des fichiers est déléguée à [FileOpener].

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';

import '../../../app/constants/app_constants.dart';
import '../../../app/theme/app_theme.dart';
import '../../../core/models/file_item.dart';
import '../../../core/services/settings_service.dart';
import '../../../core/services/trash_service.dart';
import '../../../core/utils/file_opener.dart';
import '../providers/file_explorer_provider.dart';
import '../widgets/file_list_item.dart';
import '../widgets/file_grid_item.dart';
import '../widgets/path_bar.dart';
import '../widgets/filter_bar.dart';
import '../widgets/shortcut_panel.dart';

/// @class FileExplorerScreen
/// @brief Écran principal de l'explorateur de fichiers.
class FileExplorerScreen extends StatefulWidget {
  const FileExplorerScreen({super.key});

  @override
  State<FileExplorerScreen> createState() => _FileExplorerScreenState();
}

class _FileExplorerScreenState extends State<FileExplorerScreen>
    with WidgetsBindingObserver {
  late FileExplorerProvider _provider;
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _showFilter = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _provider = FileExplorerProvider(context.read<SettingsService>());
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _provider.init();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _provider.dispose();
    super.dispose();
  }

  /// Détecte le retour depuis les Paramètres système après avoir accordé
  /// MANAGE_EXTERNAL_STORAGE et ré-initialise l'explorateur si nécessaire.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) {
      _provider.recheckAndInit();
    }
  }

  // ── Construction ───────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: _provider,
      child: Consumer<FileExplorerProvider>(
        builder: (context, prov, _) => Scaffold(
          key: _scaffoldKey,
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          appBar: _buildAppBar(context, prov),
          drawer: ShortcutPanel(
            onNavigate: (path) {
              _scaffoldKey.currentState?.closeDrawer();
              prov.navigateTo(path);
            },
          ),
          body: Column(
            children: [
              PathBar(
                currentPath:  prov.currentPath,
                onNavigate:   prov.navigateTo,
                onSegmentTap: prov.navigateToSegment,
                onUp:   prov.navigateUp,
                onUndo: prov.canUndo ? prov.undo : null,
                onRedo: prov.canRedo ? prov.redo : null,
              ),
              if (prov.needsFullStoragePermission)
                _buildPermissionBanner(),
              if (_showFilter)
                FilterBar(
                  query:             prov.filterQuery,
                  selectedCategory:  prov.filterCategory,
                  onQueryChanged:    prov.setFilterQuery,
                  onCategoryChanged: prov.setFilterCategory,
                  onClear:           prov.clearFilter,
                ),
              const Divider(height: 1),
              Expanded(child: _buildBody(context, prov)),
            ],
          ),
          floatingActionButton: prov.selectMode ? null : _buildFab(context, prov),
          bottomNavigationBar: prov.selectMode
              ? _buildSelectionBar(context, prov)
              : null,
        ),
      ),
    );
  }

  // ── AppBar ─────────────────────────────────────────────────────────────────

  AppBar _buildAppBar(BuildContext context, FileExplorerProvider prov) {
    final settings = context.watch<SettingsService>();

    return AppBar(
      toolbarHeight: 100, // augmente la hauteur
      leading: IconButton(
        icon: const Icon(Icons.menu_rounded),
        onPressed: () => _scaffoldKey.currentState?.openDrawer(),
        tooltip: 'Raccourcis',
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            prov.selectMode
                ? '${prov.selected.length} sélectionné(s)'
                : 'Explorateur',
            style: const TextStyle(fontSize: 20),
          ),

          const SizedBox(height: 8),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                IconButton(
                  icon: Icon(_showFilter
                      ? Icons.filter_list_off
                      : Icons.filter_list_rounded),
                  tooltip: 'Filtrer',
                  onPressed: () => setState(() => _showFilter = !_showFilter),
                ),
                IconButton(
                  icon: Icon(settings.viewMode == ViewMode.list
                      ? Icons.grid_view_rounded
                      : Icons.view_list_rounded),
                  tooltip: settings.viewMode == ViewMode.list
                      ? 'Vue grille'
                      : 'Vue liste',
                  onPressed: () => settings.setViewMode(
                    settings.viewMode == ViewMode.list
                        ? ViewMode.grid
                        : ViewMode.list,
                  ),
                ),
                _buildSortMenu(context, settings),
                IconButton(
                  icon: const Icon(Icons.refresh_rounded),
                  onPressed: prov.refresh,
                  tooltip: 'Actualiser',
                ),
                IconButton(
                  icon: Icon(settings.showHidden
                      ? Icons.visibility_off_rounded
                      : Icons.visibility_rounded),
                  tooltip: settings.showHidden
                      ? 'Masquer les cachés'
                      : 'Afficher les cachés',
                  onPressed: () =>
                      settings.setShowHidden(!settings.showHidden),
                ),
              ],
            ),
          ),
        ],
      ),
      actions: const [],
    );
  }

  Widget _buildSortMenu(BuildContext context, SettingsService settings) {
    const labels = <SortMode, String>{
      SortMode.name: 'Nom',
      SortMode.date: 'Date',
      SortMode.size: 'Taille',
      SortMode.type: 'Type',
    };
    return PopupMenuButton<SortMode>(
      icon: const Icon(Icons.sort_rounded),
      tooltip: 'Trier par',
      onSelected: (mode) {
        if (settings.sortMode == mode) {
          settings.setSortAsc(!settings.sortAsc);
        } else {
          settings.setSortMode(mode);
        }
      },
      itemBuilder: (_) => SortMode.values.map((m) {
        return PopupMenuItem<SortMode>(
          value: m,
          child: Row(
            children: [
              Icon(
                settings.sortMode == m
                    ? (settings.sortAsc ? Icons.arrow_upward : Icons.arrow_downward)
                    : Icons.sort,
                size: 16,
              ),
              const SizedBox(width: 8),
              Text(labels[m]!),
            ],
          ),
        );
      }).toList(),
    );
  }

  // ── Contenu principal ──────────────────────────────────────────────────────

  Widget _buildBody(BuildContext context, FileExplorerProvider prov) {
    if (prov.loading) return const Center(child: CircularProgressIndicator());
    if (prov.error != null) return _buildError(prov.error!);
    if (prov.entries.isEmpty) return _buildEmpty();

    final settings = context.watch<SettingsService>();
    return settings.viewMode == ViewMode.grid
        ? _buildGrid(context, prov)
        : _buildList(context, prov);
  }

  Widget _buildList(BuildContext context, FileExplorerProvider prov) {
    return ListView.builder(
      physics: const BouncingScrollPhysics(),
      itemCount: prov.entries.length,
      itemBuilder: (_, i) {
        final item = prov.entries[i];
        return FileListItem(
          item:        item,
          isSelected:  prov.selected.contains(item.path),
          selectMode:  prov.selectMode,
          onTap:       () => _onItemTap(context, item, prov),
          onLongPress: () => _onItemLongPress(item, prov),
          onSelect:    () => prov.toggleSelect(item.path),
        );
      },
    );
  }

  Widget _buildGrid(BuildContext context, FileExplorerProvider prov) {
    return GridView.builder(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(8),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount:   3,
        childAspectRatio: 0.85,
        crossAxisSpacing: 8,
        mainAxisSpacing:  8,
      ),
      itemCount: prov.entries.length,
      itemBuilder: (_, i) {
        final item = prov.entries[i];
        return FileGridItem(
          item:        item,
          isSelected:  prov.selected.contains(item.path),
          selectMode:  prov.selectMode,
          onTap:       () => _onItemTap(context, item, prov),
          onLongPress: () => _onItemLongPress(item, prov),
          onSelect:    () => prov.toggleSelect(item.path),
        );
      },
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.folder_open_rounded,
              size: 64,
              color: Theme.of(context).iconTheme.color?.withValues(alpha: 0.3)),
          const SizedBox(height: 16),
          Text(
            'Répertoire vide',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).iconTheme.color?.withValues(alpha: 0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildError(String msg) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline_rounded,
                size: 56,
                color: AppColors.error.withValues(alpha: 0.7)),
            const SizedBox(height: 12),
            Text(msg,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }

  // ── Bannière permission ────────────────────────────────────────────────────

  Widget _buildPermissionBanner() {
    return const MaterialBanner(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      content: Text(
        'Accès à tous les fichiers requis pour afficher l\'ensemble du stockage.',
        style: TextStyle(fontSize: 13),
      ),
      leading: Icon(Icons.folder_off_outlined),
      actions: [
        TextButton(onPressed: openAppSettings, child: Text('Paramètres')),
      ],
    );
  }

  // ── FAB ────────────────────────────────────────────────────────────────────

  Widget _buildFab(BuildContext context, FileExplorerProvider prov) {
    return FloatingActionButton(
      tooltip: 'Nouveau',
      child: const Icon(Icons.add_rounded),
      onPressed: () => _showNewItemDialog(context, prov),
    );
  }

  void _showNewItemDialog(BuildContext ctx, FileExplorerProvider prov) {
    showModalBottomSheet(
      context: ctx,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _NewItemSheet(provider: prov),
    );
  }

  // ── Barre de sélection ─────────────────────────────────────────────────────

  Widget _buildSelectionBar(BuildContext ctx, FileExplorerProvider prov) {
    final trash = context.read<TrashService>();
    return SafeArea(
      child: Container(
        height: 64,
        color: Theme.of(ctx).colorScheme.surface,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _selBtn(Icons.close_rounded,          'Désélect.',  prov.clearSelection),
            _selBtn(Icons.select_all_rounded,     'Tout',       prov.selectAll),
            _selBtn(Icons.copy_rounded,           'Copier',     () => _copySelected(ctx, prov)),
            _selBtn(Icons.cut_rounded,            'Déplacer',   () => _moveSelected(ctx, prov)),
            _selBtn(Icons.delete_outline_rounded, 'Corbeille',  () => _trashSelected(prov, trash)),
            _selBtn(Icons.delete_forever_rounded, 'Supprimer',  () => _deleteSelected(ctx, prov)),
          ],
        ),
      ),
    );
  }

  Widget _selBtn(IconData icon, String label, VoidCallback? onTap) {
    return Expanded(
      child: Tooltip(
        message: label,
        child: InkWell(
          onTap: onTap,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 22),
              const SizedBox(height: 2),
              Text(label, style: const TextStyle(fontSize: 9)),
            ],
          ),
        ),
      ),
    );
  }

  // ── Gestion des taps ───────────────────────────────────────────────────────

  void _onItemTap(BuildContext ctx, FileItem item, FileExplorerProvider prov) {
    if (prov.selectMode) {
      prov.toggleSelect(item.path);
      return;
    }
    if (item.isDirectory) {
      prov.navigateTo(item.path);
    } else {
      _openFile(ctx, item);
    }
  }

  void _onItemLongPress(FileItem item, FileExplorerProvider prov) {
    prov.toggleSelectMode();
    prov.toggleSelect(item.path);
  }

  /// @brief Ouvre un fichier via [FileOpener] avec les listes contextuelles.
  void _openFile(BuildContext ctx, FileItem item) {
    context.read<SettingsService>().addRecentFile(item.path);

    // Toutes les images du dossier pour la navigation dans le visionneur
    final allImages = item.category == FileCategory.image
        ? _provider.entries
            .where((e) => e.category == FileCategory.image)
            .map((e) => e.path)
            .toList()
        : null;

    // Tous les médias du dossier pour la lecture en séquence
    final playlist =
        (item.category == FileCategory.audio ||
                item.category == FileCategory.video)
            ? _provider.entries
                .where((e) =>
                    e.category == FileCategory.audio ||
                    e.category == FileCategory.video)
                .map((e) => e.path)
                .toList()
            : null;

    FileOpener.open(ctx, item, allImages: allImages, playlist: playlist);
  }

  // ── Actions de sélection multiple ─────────────────────────────────────────

  Future<void> _trashSelected(
      FileExplorerProvider prov, TrashService trash) async {
    for (final path in prov.selected) {
      await trash.moveToTrash(path);
    }
    prov.clearSelection();
    prov.refresh();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Éléments déplacés vers la corbeille')));
    }
  }

  Future<void> _deleteSelected(
      BuildContext ctx, FileExplorerProvider prov) async {
    final ok = await showDialog<bool>(
      context: ctx,
      builder: (_) => AlertDialog(
        title: const Text('Supprimer définitivement'),
        content: Text(
            'Supprimer ${prov.selected.length} élément(s) définitivement ?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Annuler')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child:
                Text('Supprimer', style: TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    for (final path in prov.selected) {
      final type = FileSystemEntity.typeSync(path);
      if (type == FileSystemEntityType.directory) {
        await Directory(path).delete(recursive: true);
      } else {
        await File(path).delete();
      }
    }
    prov.clearSelection();
    prov.refresh();
  }

  Future<void> _copySelected(
      BuildContext ctx, FileExplorerProvider prov) async {
    final dest = await _pickDestination(ctx, prov.currentPath);
    if (dest == null) return;
    for (final path in List.of(prov.selected)) {
      await prov.copyTo(path, dest);
    }
    prov.clearSelection();
    prov.refresh();
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Copie effectuée')));
    }
  }

  Future<void> _moveSelected(
      BuildContext ctx, FileExplorerProvider prov) async {
    final dest = await _pickDestination(ctx, prov.currentPath);
    if (dest == null) return;
    for (final path in List.of(prov.selected)) {
      await prov.rename(path, p.join(dest, p.basename(path)));
    }
    prov.clearSelection();
    prov.refresh();
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Déplacement effectué')));
    }
  }

  Future<String?> _pickDestination(BuildContext ctx, String current) async {
    final ctrl = TextEditingController(text: current);
    return showDialog<String>(
      context: ctx,
      builder: (_) => AlertDialog(
        title: const Text('Dossier de destination'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration:
              const InputDecoration(hintText: '/storage/emulated/0/…'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Annuler')),
          FilledButton(
            onPressed: () {
              final path = ctrl.text.trim();
              if (path.isNotEmpty) Navigator.pop(ctx, path);
            },
            child: const Text('Choisir'),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Feuille de création d'élément
// ─────────────────────────────────────────────────────────────────────────────

/// @class _NewItemSheet
/// @brief Bottom sheet pour créer un répertoire ou un fichier.
class _NewItemSheet extends StatefulWidget {
  final FileExplorerProvider provider;
  const _NewItemSheet({required this.provider});

  @override
  State<_NewItemSheet> createState() => _NewItemSheetState();
}

class _NewItemSheetState extends State<_NewItemSheet> {
  final _ctrl = TextEditingController();
  bool _isDir = true;

  @override
  Widget build(BuildContext ctx) {
    return Padding(
      padding: EdgeInsets.fromLTRB(
          24, 20, 24, MediaQuery.of(ctx).viewInsets.bottom + 24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Nouveau', style: Theme.of(ctx).textTheme.headlineSmall),
          const SizedBox(height: 16),
          Row(
            children: [
              ChoiceChip(
                label: const Text('Dossier'),
                selected: _isDir,
                onSelected: (_) => setState(() => _isDir = true),
              ),
              const SizedBox(width: 8),
              ChoiceChip(
                label: const Text('Fichier'),
                selected: !_isDir,
                onSelected: (_) => setState(() => _isDir = false),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _ctrl,
            autofocus: true,
            decoration: InputDecoration(
              hintText: _isDir
                  ? 'Nom du dossier'
                  : 'Nom du fichier (ex: script.py)',
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Annuler')),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () async {
                  final name = _ctrl.text.trim();
                  if (name.isEmpty) return;
                  if (_isDir) {
                    await widget.provider.createDirectory(name);
                  } else {
                    await widget.provider.createFile(name);
                  }
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('Créer'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
