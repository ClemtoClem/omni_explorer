/// @file filter_bar.dart
/// @brief Barre de filtres pour l'explorateur de fichiers.

import 'package:flutter/material.dart';
import '../../../app/constants/app_constants.dart';
import '../../../app/theme/app_theme.dart';

/// @class FilterBar
/// @brief Widget de filtrage par nom et par catégorie.
class FilterBar extends StatelessWidget {
  final String        query;
  final FileCategory? selectedCategory;
  final ValueChanged<String>        onQueryChanged;
  final ValueChanged<FileCategory?> onCategoryChanged;
  final VoidCallback                onClear;

  const FilterBar({
    super.key,
    required this.query,
    required this.selectedCategory,
    required this.onQueryChanged,
    required this.onCategoryChanged,
    required this.onClear,
  });

  static const _categories = <FileCategory, String>{
    FileCategory.folder:   'Dossiers',
    FileCategory.audio:    'Audio',
    FileCategory.video:    'Vidéo',
    FileCategory.image:    'Images',
    FileCategory.pdf:      'PDF',
    FileCategory.code:     'Code',
    FileCategory.text:     'Texte',
    FileCategory.archive:  'Archives',
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.surface,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Champ de recherche ────────────────────────────────────────────
          TextField(
            onChanged: onQueryChanged,
            decoration: InputDecoration(
              hintText: 'Rechercher dans ce répertoire...',
              prefixIcon: const Icon(Icons.search_rounded, size: 18),
              suffixIcon: query.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.close_rounded, size: 16),
                      onPressed: onClear,
                    )
                  : null,
              isDense: true,
            ),
          ),
          const SizedBox(height: 8),
          // ── Chips de catégorie ────────────────────────────────────────────
          SizedBox(
            height: 32,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: _categories.entries.map((e) {
                final isSelected = selectedCategory == e.key;
                return Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: FilterChip(
                    label: Text(e.value, style: const TextStyle(fontSize: 11)),
                    selected: isSelected,
                    onSelected: (_) => onCategoryChanged(isSelected ? null : e.key),
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    visualDensity: VisualDensity.compact,
                    selectedColor: AppColors.accent.withValues(alpha:0.2),
                    checkmarkColor: AppColors.accent,
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 4),
        ],
      ),
    );
  }
}
