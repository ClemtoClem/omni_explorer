/// @file file_list_item.dart
/// @brief Item de la vue liste de l'explorateur de fichiers.

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/models/file_item.dart';
import '../../../app/theme/app_theme.dart';
import '../../../core/utils/file_utils.dart';
import '../../../core/services/settings_service.dart';
import '../../../core/services/trash_service.dart';

/// @class FileListItem
/// @brief Ligne de l'explorateur en vue liste.
class FileListItem extends StatelessWidget {
  final FileItem    item;
  final bool        isSelected;
  final bool        selectMode;
  final VoidCallback onTap;
  final VoidCallback onLongPress;
  final VoidCallback onSelect;

  const FileListItem({
    super.key,
    required this.item,
    required this.isSelected,
    required this.selectMode,
    required this.onTap,
    required this.onLongPress,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final theme  = Theme.of(context);
    final color  = FileUtils.colorOf(item.category);
    final icon   = FileUtils.iconOf(item.category, path: item.path);

    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        color: isSelected
            ? AppColors.accent.withValues(alpha:0.12)
            : Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          children: [
            // ── Checkbox / Icône ────────────────────────────────────────────
            if (selectMode)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: onSelect,
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 150),
                    child: isSelected
                        ? Icon(Icons.check_circle_rounded,
                            color: AppColors.accent, size: 22, key: const ValueKey(true))
                        : Icon(Icons.radio_button_unchecked_rounded,
                            color: theme.iconTheme.color, size: 22, key: const ValueKey(false)),
                  ),
                ),
              ),
            // ── Icône du fichier ────────────────────────────────────────────
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: color.withValues(alpha:0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            // ── Nom + infos ─────────────────────────────────────────────────
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleMedium?.copyWith(
                      color: item.isHidden
                          ? theme.textTheme.bodySmall?.color
                          : null,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    item.isDirectory
                        ? FileUtils.formatDate(item.modified)
                        : '${FileUtils.formatSize(item.size)}  •  ${FileUtils.formatDate(item.modified)}',
                    style: theme.textTheme.bodySmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            // ── Menu contextuel ─────────────────────────────────────────────
            if (!selectMode)
              _ContextMenuBtn(item: item),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

/// @class _ContextMenuBtn
/// @brief Bouton "..." avec menu contextuel pour un fichier.
class _ContextMenuBtn extends StatelessWidget {
  final FileItem item;
  const _ContextMenuBtn({required this.item});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<_ContextAction>(
      icon: Icon(Icons.more_vert_rounded,
          size: 18, color: Theme.of(context).iconTheme.color),
      padding: EdgeInsets.zero,
      onSelected: (action) => _handleAction(context, action),
      itemBuilder: (_) => [
        const PopupMenuItem(value: _ContextAction.open,
            child: _MenuItem(Icons.open_in_new_rounded, 'Ouvrir')),
        const PopupMenuItem(value: _ContextAction.rename,
            child: _MenuItem(Icons.drive_file_rename_outline_rounded, 'Renommer')),
        const PopupMenuItem(value: _ContextAction.copy,
            child: _MenuItem(Icons.copy_rounded, 'Copier')),
        const PopupMenuItem(value: _ContextAction.cut,
            child: _MenuItem(Icons.cut_rounded, 'Couper')),
        const PopupMenuItem(value: _ContextAction.shortcut,
            child: _MenuItem(Icons.bookmark_add_outlined, 'Ajouter aux raccourcis')),
        const PopupMenuDivider(),
        PopupMenuItem(value: _ContextAction.trash,
            child: _MenuItem(Icons.delete_outline_rounded, 'Mettre à la corbeille',
                color: AppColors.error)),
      ],
    );
  }

  void _handleAction(BuildContext ctx, _ContextAction action) {
    switch (action) {
      case _ContextAction.rename:
        _showRenameDialog(ctx);
        break;
      case _ContextAction.shortcut:
        ctx.read<SettingsService>().addShortcut(item.name, item.path);
        ScaffoldMessenger.of(ctx).showSnackBar(
          SnackBar(content: Text('Raccourci créé pour « ${item.name} »')));
        break;
      case _ContextAction.trash:
        ctx.read<TrashService>().moveToTrash(item.path);
        ScaffoldMessenger.of(ctx).showSnackBar(
          SnackBar(content: Text('« ${item.name} » déplacé vers la corbeille')));
        break;
      default:
        break;
    }
  }

  void _showRenameDialog(BuildContext ctx) {
    final ctrl = TextEditingController(text: item.name);
    showDialog(
      context: ctx,
      builder: (_) => AlertDialog(
        title: const Text('Renommer'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Nouveau nom'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              // Le provider sera récupéré via le contexte parent
            },
            child: const Text('Renommer'),
          ),
        ],
      ),
    );
  }
}

enum _ContextAction { open, rename, copy, cut, trash, shortcut }

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String   label;
  final Color?   color;
  const _MenuItem(this.icon, this.label, {this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? Theme.of(context).iconTheme.color;
    return Row(
      children: [
        Icon(icon, size: 18, color: c),
        const SizedBox(width: 12),
        Text(label, style: TextStyle(color: c)),
      ],
    );
  }
}
