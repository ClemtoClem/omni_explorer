/// @file file_action_menu.dart
/// @brief Menu d'actions groupées (placeholder).
// Implémenté directement dans file_explorer_screen.dart
