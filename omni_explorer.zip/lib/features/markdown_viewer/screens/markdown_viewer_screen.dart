/// @file markdown_viewer_screen.dart
/// @brief Visionneur de fichiers Markdown avec rendu HTML via flutter_markdown.
///
/// Fonctionnalités :
/// - Rendu complet Markdown (titres, listes, tableaux, code, images, liens)
/// - Table des matières auto-générée
/// - Basculement vue source / vue rendu
/// - Partage du fichier
/// - Thème sombre/clair adapté

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

/// @class MarkdownViewerScreen
/// @brief Écran de visualisation d'un fichier Markdown.
class MarkdownViewerScreen extends StatefulWidget {
  /// Chemin du fichier Markdown à afficher.
  final String filePath;

  const MarkdownViewerScreen({super.key, required this.filePath});

  @override
  State<MarkdownViewerScreen> createState() => _MarkdownViewerScreenState();
}

class _MarkdownViewerScreenState extends State<MarkdownViewerScreen> {
  /// Contenu brut du fichier.
  String _content = '';

  /// État de chargement.
  bool _loading = true;

  /// Message d'erreur (null si pas d'erreur).
  String? _error;

  /// Afficher le source ou le rendu.
  bool _showSource = false;

  /// Table des matières extraite.
  List<_TocEntry> _toc = [];

  @override
  void initState() {
    super.initState();
    _loadFile();
  }

  /// Charge le fichier Markdown depuis le disque.
  Future<void> _loadFile() async {
    try {
      final content = await File(widget.filePath).readAsString();
      final toc = _extractToc(content);
      setState(() {
        _content = content;
        _toc = toc;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'Impossible d\'ouvrir le fichier :\n$e';
        _loading = false;
      });
    }
  }

  /// Extrait la table des matières à partir des titres Markdown (#, ##, ###).
  List<_TocEntry> _extractToc(String content) {
    final entries = <_TocEntry>[];
    final lines = content.split('\n');
    for (final line in lines) {
      final match = RegExp(r'^(#{1,3})\s+(.+)$').firstMatch(line);
      if (match != null) {
        final level = match.group(1)!.length;
        final text = match.group(2)!;
        entries.add(_TocEntry(level: level, text: text));
      }
    }
    return entries;
  }

  /// Partage le fichier.
  void _share() {
    Share.shareXFiles([XFile(widget.filePath)]);
  }

  /// Affiche la table des matières dans un bottom sheet.
  void _showToc(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => _TocSheet(entries: _toc),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          p.basename(widget.filePath),
          style: const TextStyle(fontSize: 15),
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          // Table des matières
          if (_toc.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.list_alt_outlined),
              tooltip: 'Table des matières',
              onPressed: () => _showToc(context),
            ),
          // Bascule source/rendu
          IconButton(
            icon: Icon(
              _showSource ? Icons.preview_outlined : Icons.code,
            ),
            tooltip: _showSource ? 'Voir le rendu' : 'Voir le source',
            onPressed: () => setState(() => _showSource = !_showSource),
          ),
          // Partage
          IconButton(
            icon: const Icon(Icons.share_outlined),
            tooltip: 'Partager',
            onPressed: _share,
          ),
        ],
      ),
      body: _buildBody(context, isDark),
    );
  }

  Widget _buildBody(BuildContext context, bool isDark) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48, color: Colors.red),
              const SizedBox(height: 16),
              Text(_error!, textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }

    if (_showSource) {
      // Vue source
      return Container(
        color: isDark ? const Color(0xFF1E1E2E) : const Color(0xFFF5F5F5),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Text(
            _content,
            style: TextStyle(
              fontFamily: 'monospace',
              fontSize: 13,
              height: 1.5,
              color: isDark ? Colors.white70 : Colors.black87,
            ),
          ),
        ),
      );
    }

    // Vue rendu Markdown
    return Markdown(
      data: _content,
      selectable: true,
      styleSheet: _buildStyleSheet(context, isDark),
      onTapLink: (text, href, title) async {
        if (href != null) {
          final uri = Uri.tryParse(href);
          if (uri != null && await canLaunchUrl(uri)) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
          }
        }
      },
      padding: const EdgeInsets.all(16),
    );
  }

  /// Construit la feuille de style Markdown adaptée au thème.
  MarkdownStyleSheet _buildStyleSheet(BuildContext context, bool isDark) {
    final theme = Theme.of(context);
    final textColor = isDark ? Colors.white.withAlpha(222) : Colors.black.withAlpha(222);
    final codeColor = isDark ? const Color(0xFF89B4FA) : const Color(0xFF1565C0);
    final codeBg = isDark ? const Color(0xFF313244) : const Color(0xFFEEEEEE);
    final blockquoteBg =
        isDark ? const Color(0xFF1E1E2E) : const Color(0xFFF0F0F0);

    return MarkdownStyleSheet(
      h1: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.bold,
        color: textColor,
        height: 1.4,
      ),
      h2: TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: textColor,
        height: 1.4,
      ),
      h3: TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.bold,
        color: textColor,
        height: 1.4,
      ),
      p: TextStyle(fontSize: 15, color: textColor, height: 1.6),
      code: TextStyle(
        fontFamily: 'monospace',
        fontSize: 13,
        color: codeColor,
        backgroundColor: codeBg,
      ),
      codeblockDecoration: BoxDecoration(
        color: codeBg,
        borderRadius: BorderRadius.circular(8),
      ),
      blockquoteDecoration: BoxDecoration(
        color: blockquoteBg,
        borderRadius: BorderRadius.circular(4),
        border: const Border(
          left: BorderSide(color: Color(0xFF89B4FA), width: 4),
        ),
      ),
      blockquote: TextStyle(
        color: isDark ? Colors.white60 : Colors.black54,
        fontStyle: FontStyle.italic,
      ),
      listBullet: TextStyle(color: theme.colorScheme.primary),
      tableHead: TextStyle(
        fontWeight: FontWeight.bold,
        color: textColor,
      ),
      tableBody: TextStyle(color: textColor),
      tableBorder: TableBorder.all(
        color: isDark ? Colors.white24 : Colors.black12,
      ),
      horizontalRuleDecoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            color: isDark ? Colors.white24 : Colors.black12,
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Table des matières
// ---------------------------------------------------------------------------

/// @class _TocEntry
/// @brief Entrée de la table des matières.
class _TocEntry {
  final int level;
  final String text;
  const _TocEntry({required this.level, required this.text});
}

/// @class _TocSheet
/// @brief Bottom sheet affichant la table des matières.
class _TocSheet extends StatelessWidget {
  final List<_TocEntry> entries;
  const _TocSheet({required this.entries});

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.5,
      maxChildSize: 0.9,
      minChildSize: 0.3,
      expand: false,
      builder: (ctx, scroll) {
        return Column(
          children: [
            // Indicateur drag
            Container(
              margin: const EdgeInsets.only(top: 8, bottom: 4),
              width: 36,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[400],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                'Table des matières',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                controller: scroll,
                itemCount: entries.length,
                itemBuilder: (ctx, i) {
                  final e = entries[i];
                  return ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.only(
                      left: 16.0 + (e.level - 1) * 16,
                      right: 16,
                    ),
                    leading: Text(
                      '#' * e.level,
                      style: const TextStyle(
                        color: Color(0xFF89B4FA),
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                    title: Text(e.text, style: const TextStyle(fontSize: 13)),
                    onTap: () => Navigator.pop(ctx),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
