/// @file hex_editor_screen.dart
/// @brief Éditeur hexadécimal pour fichiers binaires.
///
/// Affiche le contenu d'un fichier en colonnes offset / hex / ASCII.
/// Permet de sélectionner et modifier individuellement chaque octet.
/// Limite de chargement : 32 Mo (avertissement au-delà).

import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:path/path.dart' as p;

import '../../../app/theme/app_theme.dart';

// ─────────────────────────────────────────────────────────────────────────────

class HexEditorScreen extends StatefulWidget {
  final String path;
  const HexEditorScreen({super.key, required this.path});

  @override
  State<HexEditorScreen> createState() => _HexEditorScreenState();
}

class _HexEditorScreenState extends State<HexEditorScreen> {
  // ── Config ────────────────────────────────────────────────────────────────
  static const int _maxBytes    = 32 * 1024 * 1024; // 32 MB
  static const int _bytesPerRow = 8;

  // ── État ──────────────────────────────────────────────────────────────────
  Uint8List? _bytes;
  bool       _loading  = true;
  String?    _error;
  bool       _modified = false;
  bool       _truncated = false;

  // Sélection et édition
  int     _selectedOffset = -1;
  final bool _editMode    = true;
  final   TextEditingController _hexCtrl = TextEditingController();
  final   FocusNode            _hexFocus = FocusNode();

  // Scroll
  final ScrollController _scrollCtrl = ScrollController();

  int get _rowCount => _bytes == null
      ? 0
      : (_bytes!.length / _bytesPerRow).ceil();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _hexCtrl.dispose();
    _hexFocus.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  // ── Chargement ────────────────────────────────────────────────────────────

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final file = File(widget.path);
      if (!file.existsSync()) {
        throw Exception('Fichier introuvable');
      }
      final all = await file.readAsBytes();
      if (all.length > _maxBytes) {
        _bytes    = Uint8List.fromList(all.sublist(0, _maxBytes));
        _truncated = true;
      } else {
        _bytes    = Uint8List.fromList(all);
        _truncated = false;
      }
      _modified = false;
      _selectedOffset = -1;
    } catch (e) {
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── Sauvegarde ────────────────────────────────────────────────────────────

  Future<void> _save() async {
    if (_bytes == null || !_modified) return;
    try {
      await File(widget.path).writeAsBytes(_bytes!, flush: true);
      if (mounted) {
        setState(() => _modified = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Fichier sauvegardé')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur : $e')),
        );
      }
    }
  }

  // ── Sélection / édition d'un octet ────────────────────────────────────────

  void _selectByte(int offset) {
    if (_bytes == null || offset >= _bytes!.length) return;
    setState(() => _selectedOffset = offset);
    final hex = _bytes![offset].toRadixString(16).padLeft(2, '0').toUpperCase();
    _hexCtrl.text = hex;
    _hexCtrl.selection = TextSelection(
      baseOffset: 0, extentOffset: hex.length,
    );
    _hexFocus.requestFocus();
  }

  void _applyHexEdit() {
    final text = _hexCtrl.text.trim();
    if (text.length != 2) return;
    final value = int.tryParse(text, radix: 16);
    if (value == null || _bytes == null || _selectedOffset < 0) return;
    setState(() {
      _bytes![_selectedOffset] = value;
      _modified = true;
    });
  }

  void _navigateByte(int delta) {
    if (_bytes == null) return;
    final next = _selectedOffset + delta;
    if (next < 0 || next >= _bytes!.length) return;
    _selectByte(next);
    _scrollToOffset(next);
  }

  void _scrollToOffset(int offset) {
    if (!_scrollCtrl.hasClients) return;
    final row = offset ~/ _bytesPerRow;
    const rowHeight = 28.0;
    final target = row * rowHeight;
    final viewHeight = _scrollCtrl.position.viewportDimension;
    final current  = _scrollCtrl.offset;
    if (target < current || target + rowHeight > current + viewHeight) {
      _scrollCtrl.animateTo(
        (target - viewHeight / 2 + rowHeight / 2).clamp(
          0, _scrollCtrl.position.maxScrollExtent,
        ),
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOut,
      );
    }
  }

  // ── Confirmation avant retour si non sauvegardé ───────────────────────────

  Future<bool> _onWillPop() async {
    if (!_modified) return true;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Quitter sans sauvegarder ?'),
        content: const Text(
            'Des modifications non sauvegardées seront perdues.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Quitter'),
          ),
        ],
      ),
    );
    return ok ?? false;
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final name = p.basename(widget.path);
    return PopScope(
      canPop: !_modified,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await _onWillPop() && context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(name,
                  style: Theme.of(context).appBarTheme.titleTextStyle,
                  overflow: TextOverflow.ellipsis),
              if (_bytes != null)
                Text(
                  '${_bytes!.length} octets'
                  '${_truncated ? ' (tronqué à 32 Mo)' : ''}',
                  style: Theme.of(context).textTheme.labelSmall,
                ),
            ],
          ),
          actions: [
            if (_modified)
              IconButton(
                icon: const Icon(Icons.save_rounded),
                tooltip: 'Sauvegarder',
                onPressed: _save,
              ),
            IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Recharger',
              onPressed: _modified ? null : _load,
            ),
          ],
        ),
        body: _buildBody(),
        bottomSheet: _selectedOffset >= 0 && _bytes != null
            ? _buildEditBar()
            : null,
      ),
    );
  }

  // ── Corps principal ───────────────────────────────────────────────────────

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.error_outline_rounded,
                  size: 48, color: AppColors.error),
              const SizedBox(height: 12),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: _load, child: const Text('Réessayer')),
            ],
          ),
        ),
      );
    }
    if (_bytes == null || _bytes!.isEmpty) {
      return const Center(child: Text('Fichier vide'));
    }

    return Column(
      children: [
        // En-tête des colonnes
        _buildColumnHeader(),
        const Divider(height: 1),
        // Contenu hex
        Expanded(
          child: ListView.builder(
            controller: _scrollCtrl,
            padding: const EdgeInsets.only(bottom: 160),
            itemCount: _rowCount,
            itemExtent: 28,
            itemBuilder: (_, row) => _buildRow(row),
          ),
        ),
      ],
    );
  }

  // ── En-tête colonnes ──────────────────────────────────────────────────────

  Widget _buildColumnHeader() {
    final style = GoogleFonts.robotoMono(
      fontSize: 10,
      color: Theme.of(context).textTheme.bodySmall?.color,
      fontWeight: FontWeight.w600,
    );
    return Container(
      color: Theme.of(context).colorScheme.surface,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 68, child: Text('OFFSET', style: style)),
          Expanded(
            child: Row(
              children: List.generate(_bytesPerRow, (i) {
                return SizedBox(
                  width: 26,
                  child: Text(
                    i.toRadixString(16).toUpperCase(),
                    style: style,
                    textAlign: TextAlign.center,
                  ),
                );
              }),
            ),
          ),
          const SizedBox(width: 8),
          Text('ASCII', style: style),
        ],
      ),
    );
  }

  // ── Ligne hexadécimale ────────────────────────────────────────────────────

  Widget _buildRow(int row) {
    final bytes    = _bytes!;
    final start    = row * _bytesPerRow;
    final end      = math.min(start + _bytesPerRow, bytes.length);
    final rowBytes = bytes.sublist(start, end);

    final offsetStyle = GoogleFonts.robotoMono(
      fontSize: 11,
      color: Theme.of(context).textTheme.bodySmall?.color,
    );
    final hexStyle = GoogleFonts.robotoMono(fontSize: 12);
    final asciiStyle = GoogleFonts.robotoMono(
      fontSize: 11,
      color: Theme.of(context).textTheme.bodySmall?.color,
    );

    return Container(
      height: 28,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      color: row.isOdd
          ? Theme.of(context).colorScheme.surface.withValues(alpha: 0.4)
          : null,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Offset
          SizedBox(
            width: 68,
            child: Text(
              start.toRadixString(16).padLeft(8, '0').toUpperCase(),
              style: offsetStyle,
            ),
          ),
          // Octets hex
          Expanded(
            child: Row(
              children: List.generate(_bytesPerRow, (i) {
                final offset = start + i;
                if (i >= rowBytes.length) {
                  return const SizedBox(width: 26);
                }
                final byte = rowBytes[i];
                final isSelected = offset == _selectedOffset;
                return GestureDetector(
                  onTap: _editMode ? () => _selectByte(offset) : null,
                  child: Container(
                    width: 26,
                    height: 24,
                    alignment: Alignment.center,
                    decoration: isSelected
                        ? BoxDecoration(
                            color: AppColors.accent,
                            borderRadius: BorderRadius.circular(4),
                          )
                        : null,
                    child: Text(
                      byte.toRadixString(16).padLeft(2, '0').toUpperCase(),
                      style: hexStyle.copyWith(
                        color: isSelected
                            ? Colors.white
                            : _byteColor(byte),
                        fontWeight: isSelected
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
          // ASCII
          const SizedBox(width: 8),
          Row(
            children: rowBytes.map((b) {
              final c = (b >= 0x20 && b < 0x7F) ? String.fromCharCode(b) : '·';
              return Text(c, style: asciiStyle);
            }).toList(),
          ),
        ],
      ),
    );
  }

  // Couleur contextuelle d'un octet
  Color _byteColor(int byte) {
    final base = Theme.of(context).textTheme.bodyMedium?.color
        ?? Theme.of(context).colorScheme.onSurface;
    if (byte == 0x00) {
      return base.withValues(alpha: 0.25);
    }
    if (byte == 0xFF) {
      return AppColors.warning.withValues(alpha: 0.8);
    }
    if (byte < 0x20 || byte == 0x7F) {
      return AppColors.info.withValues(alpha: 0.8);
    }
    return base;
  }

  // ── Barre d'édition (bas d'écran) ─────────────────────────────────────────

  Widget _buildEditBar() {
    final bytes  = _bytes!;
    final offset = _selectedOffset;
    if (offset < 0 || offset >= bytes.length) return const SizedBox.shrink();

    final byte = bytes[offset];
    final dec  = byte.toString().padLeft(3, ' ');
    final char = (byte >= 0x20 && byte < 0x7F) ? String.fromCharCode(byte) : '·';

    final monoSmall = GoogleFonts.robotoMono(fontSize: 12);

    return Container(
      color: Theme.of(context).colorScheme.surface,
      padding: EdgeInsets.fromLTRB(
        12, 8, 12,
        MediaQuery.of(context).padding.bottom + 8,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Info ligne
          Row(
            children: [
              Text(
                'Offset: 0x${offset.toRadixString(16).padLeft(8, '0').toUpperCase()}',
                style: monoSmall.copyWith(
                    color: Theme.of(context).textTheme.bodySmall?.color),
              ),
              const SizedBox(width: 16),
              Text('Dec: $dec', style: monoSmall),
              const SizedBox(width: 16),
              Text("Char: '$char'", style: monoSmall),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.close_rounded, size: 18),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                onPressed: () => setState(() => _selectedOffset = -1),
                tooltip: 'Fermer',
              ),
            ],
          ),
          const SizedBox(height: 6),
          // Contrôles
          Row(
            children: [
              // Précédent
              IconButton(
                icon: const Icon(Icons.chevron_left_rounded),
                onPressed: offset > 0 ? () => _navigateByte(-1) : null,
                tooltip: 'Octet précédent',
              ),
              // Champ hex
              Expanded(
                child: TextField(
                  controller: _hexCtrl,
                  focusNode: _hexFocus,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp(r'[0-9a-fA-F]')),
                    LengthLimitingTextInputFormatter(2),
                    _UpperCaseTextFormatter(),
                  ],
                  textAlign: TextAlign.center,
                  style: GoogleFonts.robotoMono(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 4,
                  ),
                  decoration: InputDecoration(
                    isDense: true,
                    hintText: 'FF',
                    hintStyle: GoogleFonts.robotoMono(
                      fontSize: 18,
                      color: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.color
                          ?.withValues(alpha: 0.4),
                    ),
                    suffixText: '${_hexCtrl.text.length}/2',
                    suffixStyle: Theme.of(context).textTheme.labelSmall,
                  ),
                  onChanged: (val) {
                    if (val.length == 2) {
                      _applyHexEdit();
                      // Auto-avancer à l'octet suivant
                      if (offset + 1 < bytes.length) {
                        _navigateByte(1);
                      }
                    }
                  },
                  onSubmitted: (_) => _applyHexEdit(),
                ),
              ),
              // Appliquer
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () {
                  if (_hexCtrl.text.length == 2) _applyHexEdit();
                },
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 10),
                ),
                child: const Text('Appliquer'),
              ),
              // Suivant
              IconButton(
                icon: const Icon(Icons.chevron_right_rounded),
                onPressed: offset < bytes.length - 1
                    ? () => _navigateByte(1)
                    : null,
                tooltip: 'Octet suivant',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ─── Formatteur majuscules ────────────────────────────────────────────────────

class _UpperCaseTextFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue old, TextEditingValue value) {
    return value.copyWith(text: value.text.toUpperCase());
  }
}
