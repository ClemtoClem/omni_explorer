
/// @file custom_keyboard.dart
/// @brief Clavier AZERTY personnalisé : suggestions, alpha/num/emoji, barre prog.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../app/theme/app_theme.dart';

// ── Layout AZERTY ─────────────────────────────────────────────────────────────

const _rowsLower = [
  ['a','z','e','r','t','y','u','i','o','p'],
  ['q','s','d','f','g','h','j','k','l','m'],
  ['w','x','c','v','b','n',',','.'],
];
const _rowsUpper = [
  ['A','Z','E','R','T','Y','U','I','O','P'],
  ['Q','S','D','F','G','H','J','K','L','M'],
  ['W','X','C','V','B','N','?','!'],
];
const _rowsNumbers = [
  ['1','2','3','4','5','6','7','8','9','0'],
  ['!','@','#',r'$','%','^','&','*','(',')'],
  ['-','_','=','+','[',']','{','}','|','\\'],
];

const _progChars = [
  '`','~','!','@','#',r'$','%','^','&','*',
  '(',')','[',']','{','}','<','>','"',"'",
  '|','\\',';',':','/','.','?','-','_','+','=',
];

// ── Émojis ────────────────────────────────────────────────────────────────────

const _emojiCategoryIcons = ['😊', '🐶', '🍕', '💻', '❤️'];

const _emojiGroups = [
  // Visages
  [
    '😀','😃','😄','😁','😆','😅','😂','🤣','😊','😇','🙂','😉','😌','😍',
    '🥰','😘','😋','😛','😜','🤪','😎','🤩','🥳','😏','😒','😔','🥺','😢',
    '😭','😤','😠','😡','🤬','😱','😨','😰','🤗','🤔','😶','😐','😑','😬',
    '🙄','😯','😲','🥱','😴','🤢','🤮','😷','🤒','🤕','🤑','😈','💀','💩',
    '🤡','👻','👽','🤖','😺','😸','😹','😻','😼','😽','🙀','😿','😾',
  ],
  // Nature & Animaux
  [
    '🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸',
    '🐵','🐔','🐧','🐦','🐤','🦆','🦅','🦉','🐺','🐗','🐴','🦄','🐝','🦋',
    '🐌','🐞','🌱','🌲','🌳','🌴','🌵','🍀','🌺','🌻','🌹','🌷','🌸','💐',
    '⭐','🌟','✨','🌙','☀️','🌈','❄️','🌊','🌋','🍄','🌿','☘️','🦋',
  ],
  // Nourriture
  [
    '🍎','🍊','🍋','🍇','🍓','🍒','🍑','🥭','🍍','🥝','🍅','🥑','🌽','🥕',
    '🍕','🍔','🍟','🌮','🍣','🍱','🍜','🍝','🍛','🥗','🥙','🥚','🍳',
    '🧈','🥞','🧇','🥓','🌭','🍦','🍧','🎂','🍰','🍫','🍬','🍭','☕','🍵',
    '🍺','🍻','🥂','🍷','🍸','🍹','🧃','🥤','🧋',
  ],
  // Objets & Tech
  [
    '📱','💻','⌨️','🖥️','📷','📸','📹','🎥','📺','📻','💡','🔦','🔧','🔨',
    '🔩','🔗','🧲','📚','📖','✏️','📝','📊','📈','📉','📌','📍','✂️','🔐',
    '🔒','🔓','🔑','🎵','🎶','🎤','🎧','🎸','🎹','🥁','🎷','🎻','🎮','🕹️',
    '🎲','🎯','🏆','🎀','🎁','🎉','🎊','🚀','✈️','🚂','🚗','🏠','🏙️',
  ],
  // Symboles
  [
    '❤️','🧡','💛','💚','💙','💜','🖤','🤍','💔','💕','💞','💓','💗','💖',
    '💘','💝','✅','❌','⭕','🛑','⛔','🚫','💯','💢','❗','❕','❓','❔',
    '‼️','⁉️','🔱','⚜️','♻️','⚠️','💬','💭','🔥','💥','👍','👎','👏',
    '🙌','🤝','🙏','💪','👋','🫶','☮️','🆕','🆓','🆒','🆙','🆔','🆗',
  ],
];

// ── Mode clavier ──────────────────────────────────────────────────────────────

enum _KbdMode { alpha, numeric, emoji }

// ─────────────────────────────────────────────────────────────────────────────

/// Clavier AZERTY personnalisé avec suggestions, émojis et suppression du
/// clavier système Android.
class CustomKeyboard extends StatefulWidget {
  final FocusNode focusNode;
  const CustomKeyboard({super.key, required this.focusNode});

  @override
  State<CustomKeyboard> createState() => _CustomKeyboardState();
}

class _CustomKeyboardState extends State<CustomKeyboard> {
  bool     _shift   = false;
  bool     _caps    = false;
  _KbdMode _mode    = _KbdMode.alpha;
  bool     _ctrl    = false;
  bool     _alt     = false;
  bool     _visible = true;
  int      _emojiCat = 0;
  List<String> _suggestions = [];

  @override
  void initState() {
    super.initState();
    widget.focusNode.addListener(_onFocusChange);
  }

  @override
  void didUpdateWidget(CustomKeyboard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.focusNode != widget.focusNode) {
      oldWidget.focusNode.removeListener(_onFocusChange);
      widget.focusNode.addListener(_onFocusChange);
    }
  }

  @override
  void dispose() {
    widget.focusNode.removeListener(_onFocusChange);
    super.dispose();
  }

  // Masque le clavier système dès que le champ prend le focus.
  void _onFocusChange() {
    if (widget.focusNode.hasFocus && _visible) {
      SystemChannels.textInput.invokeMethod('TextInput.hide');
    }
  }

  // ── Injection de texte ────────────────────────────────────────────────────

  void _insert(String char) {
    final node = FocusManager.instance.primaryFocus;
    if (node == null) return;

    final conn = node.context?.findAncestorStateOfType<EditableTextState>();
    if (conn != null) {
      final current = conn.textEditingValue;
      final sel     = current.selection;
      if (sel.isValid) {
        final newText = current.text.replaceRange(
          sel.start.clamp(0, current.text.length),
          sel.end.clamp(0, current.text.length),
          char,
        );
        final newSel = TextSelection.collapsed(offset: sel.start + char.length);
        conn.userUpdateTextEditingValue(
          TextEditingValue(text: newText, selection: newSel),
          SelectionChangedCause.keyboard,
        );
      }
    }

    setState(() {
      if (_shift && !_caps) _shift = false;
    });
    _updateSuggestions();
  }

  void _sendSpecialKey(LogicalKeyboardKey key) {
    final conn = FocusManager.instance.primaryFocus?.context
        ?.findAncestorStateOfType<EditableTextState>();
    if (conn == null) return;

    final value = conn.textEditingValue;
    final sel   = value.selection;
    if (!sel.isValid) return;

    String        newText = value.text;
    TextSelection newSel  = sel;

    if (key == LogicalKeyboardKey.backspace) {
      if (sel.isCollapsed && sel.start > 0) {
        newText = value.text.substring(0, sel.start - 1) +
                  value.text.substring(sel.start);
        newSel  = TextSelection.collapsed(offset: sel.start - 1);
      } else if (!sel.isCollapsed) {
        newText = value.text.replaceRange(sel.start, sel.end, '');
        newSel  = TextSelection.collapsed(offset: sel.start);
      }
    } else if (key == LogicalKeyboardKey.delete) {
      if (sel.isCollapsed && sel.start < value.text.length) {
        newText = value.text.substring(0, sel.start) +
                  value.text.substring(sel.start + 1);
        newSel  = TextSelection.collapsed(offset: sel.start);
      }
    } else if (key == LogicalKeyboardKey.enter) {
      _insert('\n');
      return;
    } else if (key == LogicalKeyboardKey.tab) {
      _insert('\t');
      return;
    } else if (key == LogicalKeyboardKey.arrowLeft) {
      final pos = (sel.baseOffset - 1).clamp(0, newText.length);
      newSel = TextSelection.collapsed(offset: pos);
    } else if (key == LogicalKeyboardKey.arrowRight) {
      final pos = (sel.baseOffset + 1).clamp(0, newText.length);
      newSel = TextSelection.collapsed(offset: pos);
    } else if (key == LogicalKeyboardKey.arrowUp ||
               key == LogicalKeyboardKey.arrowDown ||
               key == LogicalKeyboardKey.pageUp ||
               key == LogicalKeyboardKey.pageDown) {
      ServicesBinding.instance.keyboard.addHandler(_handleKey);
      HardwareKeyboard.instance.addHandler(_handleKey);
      return;
    }

    if (newText != value.text || newSel != sel) {
      conn.userUpdateTextEditingValue(
        TextEditingValue(text: newText, selection: newSel),
        SelectionChangedCause.keyboard,
      );
    }
    _updateSuggestions();
  }

  bool _handleKey(KeyEvent event) {
    ServicesBinding.instance.keyboard.removeHandler(_handleKey);
    return false;
  }

  // ── Complétion automatique ────────────────────────────────────────────────

  void _updateSuggestions() {
    final conn = FocusManager.instance.primaryFocus?.context
        ?.findAncestorStateOfType<EditableTextState>();
    if (conn == null) {
      if (_suggestions.isNotEmpty) setState(() => _suggestions = []);
      return;
    }

    final value  = conn.textEditingValue;
    final text   = value.text;
    final cursor = value.selection.baseOffset;

    if (cursor <= 0) {
      if (_suggestions.isNotEmpty) setState(() => _suggestions = []);
      return;
    }

    final textBefore = text.substring(0, cursor);
    final match = RegExp(r'\w+$').firstMatch(textBefore);
    if (match == null || match.group(0)!.length < 2) {
      if (_suggestions.isNotEmpty) setState(() => _suggestions = []);
      return;
    }
    final currentWord = match.group(0)!;

    final seen  = <String>{currentWord};
    final words = <String>[];
    for (final m in RegExp(r'\w+').allMatches(text)) {
      final w = m.group(0)!;
      if (w.length > currentWord.length &&
          w.startsWith(currentWord) &&
          seen.add(w)) {
        words.add(w);
        if (words.length == 6) break;
      }
    }

    setState(() => _suggestions = words);
  }

  void _applySuggestion(String word) {
    final conn = FocusManager.instance.primaryFocus?.context
        ?.findAncestorStateOfType<EditableTextState>();
    if (conn == null) return;

    final value  = conn.textEditingValue;
    final cursor = value.selection.baseOffset;
    if (cursor <= 0) return;

    final textBefore = value.text.substring(0, cursor);
    final match = RegExp(r'\w+$').firstMatch(textBefore);
    if (match == null) return;

    final start   = cursor - match.group(0)!.length;
    final newText = value.text.substring(0, start) +
                    word +
                    value.text.substring(cursor);
    final newSel  = TextSelection.collapsed(offset: start + word.length);

    conn.userUpdateTextEditingValue(
      TextEditingValue(text: newText, selection: newSel),
      SelectionChangedCause.keyboard,
    );
    setState(() => _suggestions = []);
  }

  // ── Build principal ───────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    if (!_visible) {
      return Align(
        alignment: Alignment.bottomRight,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: FloatingActionButton.small(
            heroTag: 'kbd_show',
            onPressed: () => setState(() => _visible = true),
            child: const Icon(Icons.keyboard_rounded),
          ),
        ),
      );
    }

    final theme     = Theme.of(context);
    final isDark    = theme.brightness == Brightness.dark;
    final bg        = isDark ? AppColors.darkSurface   : AppColors.lightSurface2;
    final keyBg     = isDark ? AppColors.darkSurface2  : AppColors.lightSurface;
    final border    = isDark ? AppColors.darkBorder     : AppColors.lightBorder;
    final textColor = isDark ? AppColors.darkText       : AppColors.lightText;

    return Container(
      color: bg,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildSuggestionBar(keyBg, border, textColor),
          Divider(height: 1, color: border),
          if (_mode == _KbdMode.emoji)
            _buildEmojiKeyboard(keyBg, border, textColor)
          else ...[
            _buildProgBar(keyBg, border, textColor),
            Divider(height: 1, color: border),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
              child: Column(
                children: [
                  _buildLetterRows(keyBg, border, textColor),
                  const SizedBox(height: 4),
                  _buildBottomRow(keyBg, border, textColor),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── Barre de suggestions ──────────────────────────────────────────────────

  Widget _buildSuggestionBar(Color keyBg, Color border, Color textColor) {
    return SizedBox(
      height: 36,
      child: Row(
        children: [
          Expanded(
            child: _suggestions.isEmpty
                ? Center(
                    child: Text(
                      'Suggestions…',
                      style: TextStyle(
                        fontSize: 11,
                        color: textColor.withValues(alpha: 0.3),
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  )
                : ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 6, vertical: 4),
                    itemCount: _suggestions.length,
                    itemBuilder: (_, i) => GestureDetector(
                      onTap: () => _applySuggestion(_suggestions[i]),
                      child: Container(
                        margin: const EdgeInsets.only(right: 6),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(
                          color: keyBg,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: border),
                        ),
                        child: Text(
                          _suggestions[i],
                          style: GoogleFonts.jost(
                            fontSize: 12,
                            color: textColor,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ),
          ),
          Container(width: 1, height: 20, color: border,
              margin: const EdgeInsets.symmetric(horizontal: 2)),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: _KbdKey(
              label: '',
              icon: Icons.keyboard_hide_rounded,
              bg: keyBg, border: border, textColor: textColor,
              minWidth: 36,
              onTap: () => setState(() => _visible = false),
            ),
          ),
        ],
      ),
    );
  }

  // ── Barre de programmation ────────────────────────────────────────────────

  Widget _buildProgBar(Color keyBg, Color border, Color textColor) {
    return SizedBox(
      height: 38,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        itemCount: _progChars.length,
        itemBuilder: (_, i) => _ProgKey(
          char: _progChars[i],
          bg: keyBg, border: border, textColor: textColor,
          onTap: () => _insert(_progChars[i]),
        ),
      ),
    );
  }

  // ── Rangées de lettres / chiffres ─────────────────────────────────────────

  Widget _buildLetterRows(Color keyBg, Color border, Color textColor) {
    final rows = _mode == _KbdMode.numeric
        ? _rowsNumbers
        : (_shift || _caps ? _rowsUpper : _rowsLower);

    return Column(
      children: rows.map((row) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: row.map((c) => _KbdKey(
            label: c,
            bg: keyBg, border: border, textColor: textColor,
            onTap: () => _insert(c),
          )).toList(),
        ),
      )).toList(),
    );
  }

  // ── Clavier émoji ─────────────────────────────────────────────────────────

  Widget _buildEmojiKeyboard(Color keyBg, Color border, Color textColor) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Onglets catégories
        SizedBox(
          height: 40,
          child: Row(
            children: List.generate(_emojiCategoryIcons.length, (i) {
              final active = i == _emojiCat;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _emojiCat = i),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: active ? AppColors.accent : Colors.transparent,
                          width: 2.5,
                        ),
                      ),
                    ),
                    child: Center(
                      child: Text(
                        _emojiCategoryIcons[i],
                        style: TextStyle(fontSize: active ? 22 : 18),
                      ),
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
        // Grille d'émojis
        SizedBox(
          height: 160,
          child: GridView.builder(
            padding: const EdgeInsets.all(4),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 8,
              mainAxisSpacing: 2,
              crossAxisSpacing: 2,
            ),
            itemCount: _emojiGroups[_emojiCat].length,
            itemBuilder: (_, i) {
              final emoji = _emojiGroups[_emojiCat][i];
              return GestureDetector(
                onTap: () => _insert(emoji),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Center(
                    child: Text(emoji,
                        style: const TextStyle(fontSize: 22)),
                  ),
                ),
              );
            },
          ),
        ),
        // Navigation rapide en mode émoji
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 2, 4, 6),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _ModeKey(label: 'ABC', icon: null,
                active: false, bg: keyBg, border: border, textColor: textColor,
                onTap: () => setState(() => _mode = _KbdMode.alpha)),
              _ModeKey(label: '123', icon: null,
                active: false, bg: keyBg, border: border, textColor: textColor,
                onTap: () => setState(() => _mode = _KbdMode.numeric)),
              _ModeKey(label: '😊', icon: null,
                active: true, bg: keyBg, border: border, textColor: textColor,
                onTap: () {}),
              _KbdKey(label: '', icon: Icons.space_bar_rounded,
                bg: keyBg, border: border, textColor: textColor,
                minWidth: 80,
                onTap: () => _insert(' ')),
              _KbdKey(label: '⌫',
                bg: keyBg, border: border, textColor: textColor,
                minWidth: 36,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.backspace)),
              const SizedBox(width: 6),
              _KbdKey(label: '←',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowLeft)),
              _KbdKey(label: '↑',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowUp)),
              _KbdKey(label: '↓',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowDown)),
              _KbdKey(label: '→',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowRight)),
            ],
          ),
        ),
      ],
    );
  }

  // ── Rangée spéciale bas (alpha/numérique) ─────────────────────────────────

  Widget _buildBottomRow(Color keyBg, Color border, Color textColor) {
    return Column(
      children: [
        // Ligne 1 : Ctrl, Alt, espace, AltGr, Tab, Entrée
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _ModKey('CTRL', _ctrl, keyBg, border, textColor,
                onTap: () => setState(() => _ctrl = !_ctrl)),
            _ModKey('ALT', _alt, keyBg, border, textColor,
                onTap: () => setState(() => _alt = !_alt)),
            _KbdKey(
              label: '', icon: Icons.space_bar_rounded,
              bg: keyBg, border: border, textColor: textColor,
              minWidth: 120,
              onTap: () => _insert(' '),
            ),
            _ModKey('ALTGR', false, keyBg, border, textColor, onTap: () {}),
            _KbdKey(label: 'TAB',
              bg: keyBg, border: border, textColor: textColor, minWidth: 44,
              onTap: () => _sendSpecialKey(LogicalKeyboardKey.tab)),
            _KbdKey(label: '↵',
              bg: keyBg, border: border, textColor: textColor, minWidth: 44,
              onTap: () => _sendSpecialKey(LogicalKeyboardKey.enter)),
          ],
        ),
        const SizedBox(height: 4),
        // Ligne 2 : Shift, modes, ESC, DEL, ⌫, flèches, PgUp/Dn (scrollable)
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              if (_mode == _KbdMode.alpha)
                _ModKey(
                  _caps ? '⇪' : '⇧',
                  _shift || _caps,
                  keyBg, border, textColor,
                  minWidth: 44,
                  onTap: () => setState(() {
                    if (_shift) { _caps = !_caps; _shift = false; }
                    else        { _shift = true; }
                  }),
                ),
              _ModeKey(label: 'ABC',
                active: _mode == _KbdMode.alpha,
                bg: keyBg, border: border, textColor: textColor,
                onTap: () => setState(() => _mode = _KbdMode.alpha)),
              _ModeKey(label: '123',
                active: _mode == _KbdMode.numeric,
                bg: keyBg, border: border, textColor: textColor,
                onTap: () => setState(() => _mode = _KbdMode.numeric)),
              _ModeKey(label: '😊',
                active: _mode == _KbdMode.emoji,
                bg: keyBg, border: border, textColor: textColor,
                onTap: () => setState(() => _mode = _KbdMode.emoji)),
              _KbdKey(label: 'ESC',
                bg: keyBg, border: border, textColor: textColor, minWidth: 36,
                onTap: () {}),
              _KbdKey(label: 'DEL',
                bg: keyBg, border: border, textColor: textColor, minWidth: 36,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.delete)),
              _KbdKey(label: '⌫',
                bg: keyBg, border: border, textColor: textColor, minWidth: 36,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.backspace)),
              const SizedBox(width: 8),
              _KbdKey(label: '←',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowLeft)),
              _KbdKey(label: '↑',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowUp)),
              _KbdKey(label: '↓',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowDown)),
              _KbdKey(label: '→',
                bg: keyBg, border: border, textColor: textColor, minWidth: 32,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.arrowRight)),
              const SizedBox(width: 8),
              _KbdKey(label: 'PgU',
                bg: keyBg, border: border, textColor: textColor, minWidth: 38,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.pageUp)),
              _KbdKey(label: 'PgD',
                bg: keyBg, border: border, textColor: textColor, minWidth: 38,
                onTap: () => _sendSpecialKey(LogicalKeyboardKey.pageDown)),
            ],
          ),
        ),
      ],
    );
  }
}

// ── Widgets de touches ────────────────────────────────────────────────────────

class _KbdKey extends StatelessWidget {
  final String    label;
  final IconData? icon;
  final Color     bg, border, textColor;
  final double    minWidth;
  final VoidCallback onTap;

  const _KbdKey({
    required this.label,
    required this.bg,
    required this.border,
    required this.textColor,
    required this.onTap,
    this.icon,
    this.minWidth = 32,
  });

  @override
  Widget build(BuildContext ctx) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        constraints: BoxConstraints(minWidth: minWidth),
        height: 36,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: border),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.12),
              offset: const Offset(0, 1),
              blurRadius: 1,
            ),
          ],
        ),
        child: Center(
          child: icon != null
              ? Icon(icon, size: 16, color: textColor)
              : Text(label,
                  style: GoogleFonts.jost(
                      fontSize: 13,
                      color: textColor,
                      fontWeight: FontWeight.w500)),
        ),
      ),
    );
  }
}

class _ModKey extends StatelessWidget {
  final String    label;
  final bool      active;
  final Color     bg, border, textColor;
  final double    minWidth;
  final VoidCallback onTap;

  const _ModKey(this.label, this.active, this.bg, this.border, this.textColor,
      {required this.onTap, this.minWidth = 48});

  @override
  Widget build(BuildContext ctx) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        constraints: BoxConstraints(minWidth: minWidth),
        height: 36,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: active ? AppColors.accent.withValues(alpha: 0.25) : bg,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: active ? AppColors.accent : border,
            width: active ? 1.5 : 1,
          ),
        ),
        child: Center(
          child: Text(label,
              style: GoogleFonts.jost(
                  fontSize: 11,
                  color: active ? AppColors.accent : textColor,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5)),
        ),
      ),
    );
  }
}

/// Bouton de sélection de mode (ABC / 123 / emoji).
class _ModeKey extends StatelessWidget {
  final String?   label;
  final IconData? icon;
  final bool      active;
  final Color     bg, border, textColor;
  final VoidCallback onTap;

  const _ModeKey({
    required this.active,
    required this.bg,
    required this.border,
    required this.textColor,
    required this.onTap,
    this.label,
    this.icon,
  });

  @override
  Widget build(BuildContext ctx) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(minWidth: 40),
        height: 36,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: active ? AppColors.accent.withValues(alpha: 0.2) : bg,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: active ? AppColors.accent : border,
            width: active ? 1.5 : 1,
          ),
        ),
        child: Center(
          child: icon != null
              ? Icon(icon, size: 16,
                    color: active ? AppColors.accent : textColor)
              : Text(label ?? '',
                  style: GoogleFonts.jost(
                      fontSize: 13,
                      color: active ? AppColors.accent : textColor,
                      fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }
}

class _ProgKey extends StatelessWidget {
  final String char;
  final Color  bg, border, textColor;
  final VoidCallback onTap;

  const _ProgKey({
    required this.char,
    required this.bg,
    required this.border,
    required this.textColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext ctx) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30, height: 30,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: border),
        ),
        child: Center(
          child: Text(char,
              style: GoogleFonts.jetBrainsMono(
                  fontSize: 12,
                  color: AppColors.accent,
                  fontWeight: FontWeight.w600)),
        ),
      ),
    );
  }
}
