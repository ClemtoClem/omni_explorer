
/// @file main.dart
/// @brief Point d'entree principal de l'application OmniExplorer.
///
/// Initialise les services (SettingsService, TrashService),
/// configure les providers et lance le MaterialApp avec
/// support du theme clair/sombre.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:just_audio_background/just_audio_background.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'app/theme/app_theme.dart';
import 'core/services/settings_service.dart';
import 'core/services/trash_service.dart';
import 'features/home/screens/home_screen.dart';

// ─────────────────────────────────────────────────────────────────────────────

/// @brief Point d'entree de l'application.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Localisation intl
  await initializeDateFormatting('fr_FR', null);

  // Orientation
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);

  // just_audio_background : initialisation avec timeout pour ne pas bloquer
  // l'UI si le service Android met du temps à démarrer (1re exécution).
  try {
    await JustAudioBackground.init(
      androidNotificationChannelId: 'com.omniexplorer.channel.audio',
      androidNotificationChannelName: 'OmniExplorer Audio',
      androidNotificationOngoing: true,
    ).timeout(const Duration(seconds: 5));
  } catch (e) {
    debugPrint('[Audio] Initialisation background ignorée : $e');
  }

  // Services singleton
  final settings = SettingsService();
  try {
    await settings.init();
  } catch (e) {
    debugPrint('[Settings] init error : $e');
  }

  final trash = TrashService();
  try {
    await trash.init();
  } catch (e) {
    debugPrint('[Trash] init error : $e');
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: settings),
        ChangeNotifierProvider.value(value: trash),
      ],
      child: const OmniExplorerApp(),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────

/// @class OmniExplorerApp
/// @brief Widget racine de l'application.
class OmniExplorerApp extends StatelessWidget {
  const OmniExplorerApp({super.key});

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsService>();

    return MaterialApp(
      title:          'OmniExplorer',
      debugShowCheckedModeBanner: false,
      themeMode:      settings.themeMode,
      theme:          AppTheme.light(),
      darkTheme:      AppTheme.dark(),
      home:           const HomeScreen(),
    );
  }
}
