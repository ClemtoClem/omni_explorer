/// @file settings_service.dart
/// @brief Service de persistance des préférences utilisateur.
///
/// Gère le mode d'affichage, le tri, les raccourcis, les fichiers récents
/// et le **thème de couleur** (preset prédéfini ou personnalisé).

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../../app/constants/app_constants.dart';
import '../../app/theme/app_theme.dart';
import '../../app/theme/app_theme_presets.dart';
import '../models/file_item.dart';

/// @class SettingsService
/// @brief Singleton gérant les préférences de l'application avec SharedPreferences.
class SettingsService extends ChangeNotifier {
  static final SettingsService _instance = SettingsService._();
  factory SettingsService() => _instance;
  SettingsService._();

  late SharedPreferences _prefs;
  final _uuid = const Uuid();

  // ── État local ─────────────────────────────────────────────────────────────
  ThemeMode          _themeMode    = ThemeMode.dark;
  ThemePreset        _themePreset  = AppThemePresets.defaultPreset;
  ViewMode           _viewMode     = ViewMode.list;
  SortMode           _sortMode     = SortMode.name;
  bool               _sortAsc      = true;
  bool               _showHidden   = false;
  List<ShortcutItem> _shortcuts    = [];
  List<String>       _recentFiles  = [];

  // ── Getters ────────────────────────────────────────────────────────────────
  ThemeMode          get themeMode    => _themeMode;
  ThemePreset        get themePreset  => _themePreset;
  ViewMode           get viewMode     => _viewMode;
  SortMode           get sortMode     => _sortMode;
  bool               get sortAsc      => _sortAsc;
  bool               get showHidden   => _showHidden;
  List<ShortcutItem> get shortcuts    => List.unmodifiable(_shortcuts);
  List<String>       get recentFiles  => List.unmodifiable(_recentFiles);

  // ── Initialisation ─────────────────────────────────────────────────────────

  /// @brief Initialise le service en chargeant les préférences depuis le stockage.
  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();

    _themeMode = ThemeMode.values[
        _prefs.getInt(AppConstants.prefThemeMode) ?? ThemeMode.dark.index];
    _viewMode  = ViewMode.values[
        _prefs.getInt(AppConstants.prefViewMode) ?? 0];
    _sortMode  = SortMode.values[
        _prefs.getInt(AppConstants.prefSortBy) ?? 0];
    _sortAsc    = _prefs.getBool(AppConstants.prefSortAsc)    ?? true;
    _showHidden = _prefs.getBool(AppConstants.prefShowHidden) ?? false;

    _loadThemePreset();
    _loadShortcuts();
    _loadRecentFiles();

    // Applique le preset chargé aux couleurs statiques
    AppColors.apply(_themePreset);
  }

  // ── Thème de couleur ────────────────────────────────────────────────────────

  void _loadThemePreset() {
    final presetId = _prefs.getString(AppConstants.prefThemePreset);
    if (presetId == null) {
      _themePreset = AppThemePresets.defaultPreset;
      return;
    }
    if (presetId == 'custom') {
      final accentValue = _prefs.getInt(AppConstants.prefCustomAccent);
      if (accentValue != null) {
        _themePreset = ThemePreset.fromAccent(Color(accentValue));
      } else {
        _themePreset = AppThemePresets.defaultPreset;
      }
    } else {
      _themePreset = AppThemePresets.findById(presetId);
    }
  }

  /// @brief Applique un [ThemePreset] prédéfini.
  Future<void> setThemePreset(ThemePreset preset) async {
    _themePreset = preset;
    AppColors.apply(preset);
    await _prefs.setString(AppConstants.prefThemePreset, preset.id);
    notifyListeners();
  }

  /// @brief Applique un thème personnalisé dérivé d'une couleur d'accent.
  Future<void> setCustomAccent(Color accent) async {
    _themePreset = ThemePreset.fromAccent(accent);
    AppColors.apply(_themePreset);
    await _prefs.setString(AppConstants.prefThemePreset, 'custom');
    // ignore: deprecated_member_use
    await _prefs.setInt(AppConstants.prefCustomAccent, accent.value);
    notifyListeners();
  }

  // ── Mode clair/sombre ──────────────────────────────────────────────────────

  /// @brief Change le mode de luminosité (clair/sombre/système).
  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    await _prefs.setInt(AppConstants.prefThemeMode, mode.index);
    notifyListeners();
  }

  // ── Affichage ──────────────────────────────────────────────────────────────

  Future<void> setViewMode(ViewMode mode) async {
    _viewMode = mode;
    await _prefs.setInt(AppConstants.prefViewMode, mode.index);
    notifyListeners();
  }

  Future<void> setSortMode(SortMode mode) async {
    _sortMode = mode;
    await _prefs.setInt(AppConstants.prefSortBy, mode.index);
    notifyListeners();
  }

  Future<void> setSortAsc(bool asc) async {
    _sortAsc = asc;
    await _prefs.setBool(AppConstants.prefSortAsc, asc);
    notifyListeners();
  }

  Future<void> setShowHidden(bool show) async {
    _showHidden = show;
    await _prefs.setBool(AppConstants.prefShowHidden, show);
    notifyListeners();
  }

  // ── Raccourcis ─────────────────────────────────────────────────────────────

  void _loadShortcuts() {
    final raw = _prefs.getString(AppConstants.prefShortcuts);
    if (raw == null) return;
    try {
      final list = jsonDecode(raw) as List;
      _shortcuts =
          list.map((e) => ShortcutItem.fromMap(e as Map<String, dynamic>)).toList();
    } catch (_) {}
  }

  Future<void> _saveShortcuts() async {
    await _prefs.setString(
      AppConstants.prefShortcuts,
      jsonEncode(_shortcuts.map((e) => e.toMap()).toList()),
    );
  }

  Future<void> addShortcut(String name, String path) async {
    if (_shortcuts.any((s) => s.path == path)) return;
    _shortcuts.add(ShortcutItem(id: _uuid.v4(), name: name, path: path));
    await _saveShortcuts();
    notifyListeners();
  }

  Future<void> removeShortcut(String id) async {
    _shortcuts.removeWhere((s) => s.id == id);
    await _saveShortcuts();
    notifyListeners();
  }

  // ── Fichiers récents ───────────────────────────────────────────────────────

  void _loadRecentFiles() {
    _recentFiles = _prefs.getStringList(AppConstants.prefRecentFiles) ?? [];
  }

  Future<void> addRecentFile(String path) async {
    _recentFiles.remove(path);
    _recentFiles.insert(0, path);
    if (_recentFiles.length > AppConstants.maxRecentFiles) {
      _recentFiles = _recentFiles.sublist(0, AppConstants.maxRecentFiles);
    }
    await _prefs.setStringList(AppConstants.prefRecentFiles, _recentFiles);
    notifyListeners();
  }

  Future<void> clearRecentFiles() async {
    _recentFiles.clear();
    await _prefs.setStringList(AppConstants.prefRecentFiles, []);
    notifyListeners();
  }
}